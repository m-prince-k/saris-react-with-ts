import { FC } from "react";
import { KTIcon, toAbsoluteUrl } from "../../../_metronic/helpers";
import { Link } from "react-router-dom";
import { Dropdown1 } from "../../../_metronic/partials";
import { useLocation } from "react-router";
import { ToolbarWrapper } from "../../../_metronic/layout/components/toolbar";
import { Content } from "../../../_metronic/layout/components/content";

const AccountHeader: FC = () => {
  const location = useLocation();

  return (
    <>
      <ToolbarWrapper />
      <Content>This is first header hh</Content>
    </>
  );
};

export { AccountHeader };
