import React from 'react'
import {Navigate, Route, Routes, Outlet} from 'react-router-dom'
import {PageLink, PageTitle} from '../../../_metronic/layout/core'
import {Overview} from './components/Overview'
import {Settings} from './components/settings/Settings'
import {AccountHeader} from './AccountHeader'
import { ViewGenerations } from '../../pages/report/ViewGenerations'


const accountBreadCrumbs: Array<PageLink> = [
  {
    title: 'Account',
    path: '/crafted/account/overview',
    isSeparator: false,
    isActive: false,
  },
  {
    title: '',
    path: '',
    isSeparator: true,
    isActive: false,
  },
]

const AccountPage: React.FC = () => {
  return (
    <Routes>
      <Route
        element={
          <>
            <AccountHeader />
            <Outlet />
          </>
        }
      >


<Route
          path='viewgenerations'
          element={
            <>
              <PageTitle breadcrumbs={accountBreadCrumbs}>View Generations</PageTitle>
              <ViewGenerations />
            </>
          }
        />

        <Route
          path='trunkfitguide'
          element={
            <>
              <PageTitle breadcrumbs={accountBreadCrumbs}>Trunk Fit Guide</PageTitle>
              <Overview />
            </>
          }
        />
        <Route
          path='exportfitguide'
          element={
            <>
              <PageTitle breadcrumbs={accountBreadCrumbs}>Export Fit Guide</PageTitle>
              <Settings />
            </>
          }
        />
        <Route index element={<Navigate to='/crafted/account/overview' />} />
      </Route>
    </Routes>
  )
}

export default AccountPage
