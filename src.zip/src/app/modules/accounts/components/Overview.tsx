import {Link} from 'react-router-dom'
import {KTIcon} from '../../../../_metronic/helpers'
import {
  ChartsWidget1,
  ListsWidget5,
  TablesWidget1,
  TablesWidget5,
} from '../../../../_metronic/partials/widgets'
import { Content } from '../../../../_metronic/layout/components/content'

export function Overview() {
  return (
    <Content>
      <h1>this is second header</h1>
    </Content>
  )
}
