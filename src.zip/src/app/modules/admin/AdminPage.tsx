import { Navigate, Route, Routes, Outlet } from "react-router-dom";
import { PageLink, PageTitle } from "../../../_metronic/layout/core";
import { Charts } from "./components/Charts";
import { Feeds } from "./components/Feeds";
import { Racks } from "./components/racks/Racks";
import { Tables } from "./components/Tables";
import { Mixed } from "./components/Mixed";
import { Notes } from "./components/Notes";
import { AddNewRacks } from "./components/racks/AddNewRacks";
// import { NoteListWrapper } from "./components/notes/note-list/NotesList";
import { Regions } from "./components/Regions/Regions";
import { RackTypesListing } from "./components/Rack Types/RackTypesListing";
import { Settings } from "./components/Settings/Settings";
import { PhotoListWrapper } from "./components/photo/PhotoList";
import { NoteListWrapper } from "../admin/components/notes/note-list/NotesList";



const widgetsBreadCrumbs: Array<PageLink> = [
  {
    title: "Admin",
    path: "/admin",
    isSeparator: false,
    isActive: false,
  },
  {
    title: "",
    path: "",
    isSeparator: true,
    isActive: false,
  },
];

const AdminPage = () => {
  return (
    <Routes>
      <Route element={<Outlet />}>
        <Route
          path="racks"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Racks</PageTitle>
              <Racks />

              {/* <Charts /> */}
            </>
          }
        />
        <Route
          path="Regions"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Regions</PageTitle>
              <Regions />
            </>
          }
        />
        <Route
          path="rack-types"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Rack Types</PageTitle>
              <RackTypesListing isUserLoading={false} region={{
                id: undefined,
                name: undefined,
                avatar: undefined,
                email: undefined,
                position: undefined,
                role: undefined,
                last_login: undefined,
                two_steps: undefined,
                joined_day: undefined,
                online: undefined,
                region_name: undefined,
                metric_ind: undefined,
                model_year_plus_one_ind: undefined,
                initials: undefined,
                reference: undefined,
                note: undefined,
                rack_type_id: undefined,
                language: undefined,
                no_fit_ind: undefined
              }} />
            </>
          }
        />
        {/* <Route
          path="Settings"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Settings</PageTitle>
              <Settings />


            </>
          }
        /> */}
        <Route
          path="racks/add-racks"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>
                Add New Racks
              </PageTitle>
              <AddNewRacks
                isUserLoading={false}
                rack={{
                  id: undefined,
                  name: undefined,
                  obsolete_ind: undefined,
                  rack_number: undefined,
                  rack_type_id: undefined,
                  rack_support_style_id: undefined,
                  receiver_class_id: undefined,
                  max_bikes: undefined,
                  tilts: undefined,
                  heavy_bike_ind: undefined,
                  fit_guide_column: undefined,
                  fit_guide_group: undefined,
                  rack_overview: undefined,
                  use_rack_saddle_to_ground: undefined,
                  use_trunk_opens_with_clips_ind: undefined,
                  use_rack_saddle_to_license: undefined,
                  use_arm_position: undefined,
                  use_leg_position: undefined,
                  use_arm_angle: undefined,
                  use_top_feet_spoiler_location_id: undefined,
                  use_rack_location_id: undefined,
                  use_top_strap_location_id: undefined,
                  use_bottom_strap_location_id: undefined,
                  use_bottom_feet_surface_id: undefined,
                  use_position_with_spoiler: undefined,
                  use_position_without_spoiler: undefined,
                  use_lower_feet_to_crossbar: undefined,
                  use_lower_feet_location_id: undefined,
                  initials: undefined,
                  reference: undefined,
                  note: undefined,
                  language: undefined,
                  no_fit_ind: undefined,
                }}
              />
            </>
          }
        />
        <Route
          path="notes"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Notes</PageTitle>
              <NoteListWrapper />
            </>
          }
        />

        <Route
          path="photos"
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Photos</PageTitle>
              <PhotoListWrapper />
            </>
          }
        />

        {/*<Route
          path='mixed'
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Mixed</PageTitle>
              <Mixed />
            </>
          }
        />
        <Route
          path='tables'
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Tables</PageTitle>
              <Tables />
            </>
          }
        />
        <Route
          path='statistics'
          element={
            <>
              <PageTitle breadcrumbs={widgetsBreadCrumbs}>Statiscics</PageTitle>
              <Statistics />
            </>
          }
        /> */}
        <Route index element={<Navigate to="/crafted/widgets/lists" />} />
      </Route>
    </Routes>
  );
};

export default AdminPage;
