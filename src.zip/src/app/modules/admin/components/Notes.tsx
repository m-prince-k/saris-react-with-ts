import { FC } from "react";
import Select from "react-select";
import {
  StatisticsWidget1,
  StatisticsWidget2,
  StatisticsWidget3,
  StatisticsWidget4,
  StatisticsWidget5,
  StatisticsWidget6,
} from "../../../../_metronic/partials/widgets";
import { ToolbarWrapper } from "../../../../_metronic/layout/components/toolbar";
import { Content } from "../../../../_metronic/layout/components/content";

const Notes: FC = () => {
  return (
    <>
      <ToolbarWrapper />
      <Content>
        <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
          <div className="card-header cursor-pointer">
            <div className="card-title m-0">
              <h3 className="fw-bold m-0">Rack Details</h3>
            </div>
            <a href="/" className="btn btn-sm btn-warning align-self-center">
              Edit Rack
            </a>
          </div>
          <div className="card-body">
            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Name
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <input
                  type="text"
                  name="company"
                  className="form-control form-control-lg "
                  placeholder="Bones (2 Bike)"
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6"></label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <div className="d-flex align-items-center mt-3">
                  <label className="form-check form-check-custom form-check-inline me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value="1"
                    />
                    <span className="fw-semibold ps-2 fs-6">Obsolete</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Rack Number
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <input
                  type="text"
                  name="company"
                  className="form-control form-control-lg "
                  placeholder="Bones (2 Bike)"
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Type
              </label>

              <div
                className="col-lg-8 fv-row fv-plugins-icon-container"
                data-select2-id="select2-data-281-edpc"
              >
                {/* <select
                  name="language"
                  aria-label="Select a Language"
                  data-control="select2"
                  data-placeholder="Trunk"
                  className="form-select form-select-solid form-select-lg select2-hidden-accessible"
                  data-select2-id="select2-data-12-lswl"
                  aria-hidden="true"
                  data-kt-initialized="1"
                >
                  <option value="" data-select2-id="select2-data-14-chmy">
                    Trunk
                  </option>
                  <option
                    data-kt-flag="flags/indonesia.svg"
                    value="id"
                    data-select2-id="select2-data-282-ssyf"
                  >
                    Bahasa Indonesia - Indonesian
                  </option>
                </select> */}

                <Select
                  className="select2-hidden-accessible sel-box"
                  placeholder="Trunk"
                  options={[
                    { value: "select", label: "Select Trunk" },
                    {
                      value: "Bahasa Indonesia - Indonesian",
                      label: "Bahasa Indonesia - Indonesian",
                    },
                  ]}
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Rack Support Style
              </label>

              <div
                className="col-lg-8 fv-row fv-plugins-icon-container"
                data-select2-id="select2-data-281-edpc"
              >
                {/* <select
                  name="language"
                  aria-label="Rack Support Style"
                  data-control="select2"
                  data-placeholder="Trunk"
                  className="form-select form-select-solid form-select-lg select2-hidden-accessible"
                  data-select2-id="select2-data-12-lswl"
                  aria-hidden="true"
                  data-kt-initialized="1"
                >
                  <option value="" data-select2-id="select2-data-14-chmy">
                    Rack Support Style
                  </option>
                  <option
                    data-kt-flag="flags/indonesia.svg"
                    value="id"
                    data-select2-id="select2-data-282-ssyf"
                  >
                    Bahasa Indonesia - Indonesian
                  </option>
                </select> */}

                <Select
                  className="select2-hidden-accessible sel-box"
                  placeholder="Rack Support Style"
                  options={[
                    { value: "select", label: "Rack Support Style" },
                    {
                      value: "Bahasa Indonesia - Indonesian",
                      label: "Bahasa Indonesia - Indonesian",
                    },
                  ]}
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Receiver Class
              </label>

              <div
                className="col-lg-8 fv-row fv-plugins-icon-container"
                data-select2-id="select2-data-281-edpc"
              >
                {/* <select
                  name="language"
                  aria-label="Select"
                  data-control="select2"
                  data-placeholder="Trunk"
                  className="form-select form-select-solid form-select-lg select2-hidden-accessible"
                  data-select2-id="select2-data-12-lswl"
                  aria-hidden="true"
                  data-kt-initialized="1"
                >
                  <option value="" data-select2-id="select2-data-14-chmy">
                    Select
                  </option>
                  <option
                    data-kt-flag="flags/indonesia.svg"
                    value="id"
                    data-select2-id="select2-data-282-ssyf"
                  >
                    Bahasa Indonesia - Indonesian
                  </option>
                </select> */}

                <Select
                  className="select2-hidden-accessible sel-box"
                  placeholder="Rack Support Style"
                  options={[
                    { value: "select", label: "Rack Support Style" },
                    {
                      value: "Bahasa Indonesia - Indonesian",
                      label: "Bahasa Indonesia - Indonesian",
                    },
                  ]}
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Maximum Bikes
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <input
                  type="text"
                  name="company"
                  className="form-control form-control-lg"
                  placeholder="2"
                />
              </div>
            </div>
            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6"></label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <div className="d-flex align-items-center mt-3">
                  <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value="1"
                    />
                    <span className="fw-semibold ps-2 fs-6">Tilts</span>
                  </label>

                  <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value="1"
                    />
                    <span className="fw-semibold ps-2 fs-6">
                      Electric/Heavy Bikes
                    </span>
                  </label>
                </div>
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Fit Guide
              </label>
              <div className="col-lg-8">
                <div className="row">
                  <div className="col-lg-6 fv-row fv-plugins-icon-container">
                    <input
                      type="text"
                      name="fname"
                      className="form-control form-control-lg mb-3 mb-lg-0"
                      placeholder="Column"
                      value="1"
                    />
                  </div>

                  <div className="col-lg-6 fv-row fv-plugins-icon-container">
                    <input
                      type="text"
                      name="lname"
                      className="form-control form-control-lg"
                      placeholder="Group "
                      value=""
                    />
                  </div>
                  <div className="form-text">
                    If Column is not empty, the rack will be shown on the fit
                    guide. Use Group to put the fit information for more than
                    one rack in the same column.
                  </div>
                </div>
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Overview
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <textarea
                  name="msg"
                  placeholder="Comments"
                  className="form-control mb-3 mb-lg-0"
                >
                  Simply the finest trunk rack on the market. Carries up to two
                  bikes.
                </textarea>
              </div>
            </div>
          </div>
        </div>

        <div className="card mb-5 mb-xl-10">
          <div className="card-header cursor-pointer">
            <div className="card-title m-0">
              <h3 className="fw-bold m-0">Fit Input Fields</h3>
            </div>
          </div>
          <div className="card-body">
            <div className="row ">
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Position With Spoiler
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Top Feet Spoiler Location
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Position Without Spoiler
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Rack Location</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Trunk Opens With Clips
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Top Strap Location</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Arm Position</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Bottom Strap Location
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Leg Position</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Bottom Feet Surface</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Rack Saddle To Ground
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Lower Feet To Crossbar
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Rack Saddle To License
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Angle of Arms</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-header border-0 pt-6">
            <div className="card-title">Notes</div>
            <div className="card-toolbar">
              <div
                className="d-flex justify-content-end"
                data-kt-user-table-toolbar="base"
              >
                <button type="button" className="btn btn-warning">
                  <i className="ki-duotone ki-plus fs-2"></i>Add New
                </button>
              </div>
            </div>
          </div>
          <div className="card-body">
            <div id="" className="table-responsive">
              <table
                className="table align-middle table-row-dashed fs-6 gy-5 dataTable"
                id="kt_customers_table"
              >
                <thead>
                  <tr
                    className="text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0"
                    role="row"
                  >
                    <th className="w-10px pe-2 dt-orderable-none">Obs</th>
                    <th
                      className="min-w-125px dt-orderable-asc dt-orderable-desc"
                      data-dt-column="1"
                      aria-label="Customer Name: Activate to sort"
                    >
                      <span className="dt-column-title" role="button">
                        Rack
                      </span>
                      <span className="dt-column-order"></span>
                    </th>
                    <th
                      className="min-w-125px dt-orderable-asc dt-orderable-desc"
                      data-dt-column="2"
                      aria-label="Email: Activate to sort"
                    >
                      <span className="dt-column-title" role="button">
                        Number
                      </span>
                      <span className="dt-column-order"></span>
                    </th>
                    <th
                      className="min-w-125px dt-orderable-asc dt-orderable-desc"
                      data-dt-column="3"
                      aria-label="Company: Activate to sort"
                    >
                      <span className="dt-column-title" role="button">
                        Type
                      </span>
                      <span className="dt-column-order"></span>
                    </th>
                    <th
                      className="min-w-125px dt-orderable-asc dt-orderable-desc"
                      data-dt-column="4"
                      aria-label="Payment Method: Activate to sort"
                    >
                      <span className="dt-column-title" role="button">
                        Style
                      </span>
                      <span className="dt-column-order"></span>
                    </th>
                  </tr>
                </thead>
                <tbody className="fw-semibold text-gray-600">
                  <tr>
                    <td>
                      <div className="form-check form-check-sm form-check-custom form-check-solid">
                        <input
                          className="form-check-input"
                          type="checkbox"
                          value="1"
                        />
                      </div>
                    </td>
                    <td>
                      <p className="text-gray-800 text-hover-primary mb-1">
                        Bones (2 Bike)
                      </p>
                    </td>
                    <td>805BL</td>
                    <td>Trunk</td>
                    <td>Hanging</td>
                  </tr>
                </tbody>
                <tfoot></tfoot>
              </table>
            </div>
          </div>
        </div>

        {/* begin::Row */}
        <div className="row g-5 g-xl-8">
          <div className="col-xl-4">
            <StatisticsWidget2
              className="card-xl-stretch mb-xl-8"
              avatar="/media/svg/avatars/029-boy-11.svg"
              title="Arthur Goldstain"
              description="System & Software Architect"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget2
              className="card-xl-stretch mb-xl-8"
              avatar="/media/svg/avatars/014-girl-7.svg"
              title="Lisa Bold"
              description="Marketing & Fanance Manager"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget2
              className="card-xl-stretch mb-5 mb-xl-8"
              avatar="/media/svg/avatars/004-boy-1.svg"
              title="Nick Stone"
              description="Customer Support Team"
            />
          </div>
        </div>
        {/* end::Row */}

        {/* begin::Row */}
        <div className="row g-5 g-xl-8">
          <div className="col-xl-4">
            <StatisticsWidget3
              className="card-xl-stretch mb-xl-8"
              color="success"
              title="Weekly Sales"
              description="Your Weekly Sales Chart"
              change="+100"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget3
              className="card-xl-stretch mb-xl-8"
              color="danger"
              title="Authors Progress"
              description="Marketplace Authors Chart"
              change="-260"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget3
              className="card-xl-stretch mb-5 mb-xl-8"
              color="primary"
              title="Sales Progress"
              description="Marketplace Sales Chart"
              change="+180"
            />
          </div>
        </div>
        {/* end::Row */}

        {/* begin::Row */}
        <div className="row g-5 g-xl-8">
          <div className="col-xl-4">
            <StatisticsWidget4
              className="card-xl-stretch mb-xl-8"
              svgIcon="basket"
              color="info"
              description="Sales Change"
              change="+256"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget4
              className="card-xl-stretch mb-xl-8"
              svgIcon="element-11"
              color="success"
              description="Weekly Income"
              change="750$"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget4
              className="card-xl-stretch mb-5 mb-xl-8"
              svgIcon="briefcase"
              color="primary"
              description="New Users"
              change="+6.6K"
            />
          </div>
        </div>
        {/* end::Row */}

        {/* begin::Row */}
        <div className="row g-5 g-xl-8">
          <div className="col-xl-4">
            <StatisticsWidget5
              className="card-xl-stretch mb-xl-8"
              svgIcon="basket"
              color="danger"
              iconColor="white"
              title="Shopping Cart"
              titleColor="white"
              description="Lands, Houses, Ranchos, Farms"
              descriptionColor="white"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget5
              className="card-xl-stretch mb-xl-8"
              svgIcon="cheque"
              color="primary"
              iconColor="white"
              title="Appartments"
              titleColor="white"
              description="Flats, Shared Rooms, Duplex"
              descriptionColor="white"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget5
              className="card-xl-stretch mb-5 mb-xl-8"
              svgIcon="chart-simple-3"
              color="success"
              iconColor="white"
              title="Sales Stats"
              titleColor="white"
              description="50% Increased for FY20"
              descriptionColor="white"
            />
          </div>
        </div>
        {/* end::Row */}

        {/* begin::Row */}
        <div className="row g-5 g-xl-8">
          <div className="col-xl-3">
            <StatisticsWidget5
              className="card-xl-stretch mb-xl-8"
              svgIcon="chart-simple"
              color="white"
              iconColor="primary"
              title="500M$"
              description="SAP UI Progress"
            />
          </div>

          <div className="col-xl-3">
            <StatisticsWidget5
              className="card-xl-stretch mb-xl-8"
              svgIcon="cheque"
              color="dark"
              iconColor="white"
              title="+3000"
              titleColor="white"
              description="New Customers"
              descriptionColor="white"
            />
          </div>

          <div className="col-xl-3">
            <StatisticsWidget5
              className="card-xl-stretch mb-xl-8"
              svgIcon="briefcase"
              color="warning"
              iconColor="white"
              title="$50,000"
              titleColor="white"
              description="Milestone Reached"
              descriptionColor="white"
            />
          </div>

          <div className="col-xl-3">
            <StatisticsWidget5
              className="card-xl-stretch mb-5 mb-xl-8"
              svgIcon="chart-pie-simple"
              color="info"
              iconColor="white"
              title="$50,000"
              titleColor="white"
              description="Milestone Reached"
              descriptionColor="white"
            />
          </div>
        </div>
        {/* end::Row */}

        {/* begin::Row */}
        <div className="row g-5 g-xl-8">
          <div className="col-xl-4">
            <StatisticsWidget6
              className="card-xl-stretch mb-xl-8"
              color="success"
              title="Avarage"
              description="Project Progress"
              progress="50%"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget6
              className="card-xl-stretch mb-xl-8"
              color="warning"
              title="48k Goal"
              description="Company Finance"
              progress="15%"
            />
          </div>

          <div className="col-xl-4">
            <StatisticsWidget6
              className="card-xl-stretch mb-xl-8"
              color="primary"
              title="400k Impressions"
              description="Marketing Analysis"
              progress="76%"
            />
          </div>
        </div>
        {/* end::Row */}
      </Content>
    </>
  );
};

export { Notes };
