import { FC } from "react";
import Select from "react-select";
import {
  StatisticsWidget1,
  StatisticsWidget2,
  StatisticsWidget3,
  StatisticsWidget4,
  StatisticsWidget5,
  StatisticsWidget6,
} from "../../../../../_metronic/partials/widgets";
import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { Content } from "../../../../../_metronic/layout/components/content";

const AddNewRackType: FC = () => {
  return (
    <>
      <ToolbarWrapper />
      <Content>
        <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
          <div className="card-header">
            <div className="card-title m-0">
              <h3 className="fw-bold m-0">Rack Details</h3>
            </div>
            {/* <a href="/" className="btn btn-sm btn-warning align-self-center">
              Edit Rack
            </a> */}
          </div>
          <div className="card-body">
            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Name
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <input
                  type="text"
                  name="company"
                  className="form-control form-control-lg "
                  placeholder="Bones (2 Bike)"
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6"></label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <div className="d-flex align-items-center mt-3">
                  <label className="form-check form-check-custom form-check-inline me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value="1"
                    />
                    <span className="fw-semibold ps-2 fs-6">Obsolete</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Rack Number
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <input
                  type="text"
                  name="company"
                  className="form-control form-control-lg "
                  placeholder="Bones (2 Bike)"
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Type
              </label>

              <div
                className="col-lg-8 fv-row fv-plugins-icon-container"
                data-select2-id="select2-data-281-edpc"
              >
                

                <Select
                  className="select2-hidden-accessible sel-box"
                  placeholder="Trunk"
                  options={[
                    { value: "select", label: "Select Trunk" },
                    {
                      value: "Bahasa Indonesia - Indonesian",
                      label: "Bahasa Indonesia - Indonesian",
                    },
                  ]}
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Rack Support Style
              </label>

              <div
                className="col-lg-8 fv-row fv-plugins-icon-container"
                data-select2-id="select2-data-281-edpc"
              >
                

                <Select
                  className="select2-hidden-accessible sel-box"
                  placeholder="Rack Support Style"
                  options={[
                    { value: "select", label: "Rack Support Style" },
                    {
                      value: "Bahasa Indonesia - Indonesian",
                      label: "Bahasa Indonesia - Indonesian",
                    },
                  ]}
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Receiver Class
              </label>

              <div
                className="col-lg-8 fv-row fv-plugins-icon-container"
                data-select2-id="select2-data-281-edpc"
              >
                

                <Select
                  className="select2-hidden-accessible sel-box"
                  placeholder="Rack Support Style"
                  options={[
                    { value: "select", label: "Rack Support Style" },
                    {
                      value: "Bahasa Indonesia - Indonesian",
                      label: "Bahasa Indonesia - Indonesian",
                    },
                  ]}
                />
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Maximum Bikes
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <input
                  type="text"
                  name="company"
                  className="form-control form-control-lg"
                  placeholder="2"
                />
              </div>
            </div>
            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6"></label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <div className="d-flex align-items-center mt-3">
                  <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value="1"
                    />
                    <span className="fw-semibold ps-2 fs-6">Tilts</span>
                  </label>

                  <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value="1"
                    />
                    <span className="fw-semibold ps-2 fs-6">
                      Electric/Heavy Bikes
                    </span>
                  </label>
                </div>
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Fit Guide
              </label>
              <div className="col-lg-8">
                <div className="row">
                  <div className="col-lg-6 fv-row fv-plugins-icon-container">
                    <input
                      type="text"
                      name="fname"
                      className="form-control form-control-lg mb-3 mb-lg-0"
                      placeholder="Column"
                      value="1"
                    />
                  </div>

                  <div className="col-lg-6 fv-row fv-plugins-icon-container">
                    <input
                      type="text"
                      name="lname"
                      className="form-control form-control-lg"
                      placeholder="Group "
                      value=""
                    />
                  </div>
                  <div className="form-text">
                    If Column is not empty, the rack will be shown on the fit
                    guide. Use Group to put the fit information for more than
                    one rack in the same column.
                  </div>
                </div>
              </div>
            </div>

            <div className="row mb-6">
              <label className="col-lg-4 col-form-label fw-semibold fs-6">
                Overview
              </label>
              <div className="col-lg-8 fv-row fv-plugins-icon-container">
                <textarea
                  name="msg"
                  placeholder="Comments"
                  className="form-control mb-3 mb-lg-0"
                >
                  Simply the finest trunk rack on the market. Carries up to two
                  bikes.
                </textarea>
              </div>
            </div>
          </div>
        </div>

        <div className="card mb-5 mb-xl-10">
          <div className="card-header">
            <div className="card-title m-0">
              <h3 className="fw-bold m-0">Fit Input Fields</h3>
            </div>
          </div>
          <div className="card-body">
            <div className="row ">
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Position With Spoiler
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Top Feet Spoiler Location
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Position Without Spoiler
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Rack Location</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Trunk Opens With Clips
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Top Strap Location</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Arm Position</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Bottom Strap Location
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Leg Position</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Bottom Feet Surface</span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Rack Saddle To Ground
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Lower Feet To Crossbar
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">
                    Rack Saddle To License
                  </span>
                </label>
              </div>
              <div className="col-lg-3 fv-row mb-6">
                <label className="form-check form-check-inline form-check-solid me-5">
                  <input
                    className="form-check-input"
                    name="communication[]"
                    type="checkbox"
                  />
                  <span className="fw-bold ps-2 fs-6">Angle of Arms</span>
                </label>
              </div>
            </div>
          </div>
        </div>

        <div className="mb-5 mb-xl-10">
         
          <div className="d-flex">
            <button type="submit" id="kt_ecommerce_add_product_submit" className="btn btn-warning">
              <span className="indicator-label">Submit</span></button>
          </div>
      
          </div>


      </Content>
    </>
  );
};

export { AddNewRackType };
