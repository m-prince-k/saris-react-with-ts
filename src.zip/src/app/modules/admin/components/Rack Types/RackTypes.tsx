import { FC } from "react";
// import {
//   ListsWidget1,
//   ListsWidget2,
//   ListsWidget3,
//   ListsWidget4,
//   ListsWidget5,
//   ListsWidget6,
//   ListsWidget7,
//   ListsWidget8,
// } from "../../../../_metronic/partials/widgets";



import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { Link } from "react-router-dom";
import { RackTypesListing } from "./RackTypesListing";


// import { RegionListing } from "./RackTypesListing";
// import { RegionEditModal } from "./region-edit-model/regionEditModal";
// import { Content } from "../../../../_metronic/layout/components/content";
// import { Link } from "react-router-dom";
// import { Routes, Route, BrowserRouter, Navigate } from "react-router-dom";

const RackTypes: FC = () => {
  return (
    <>
      <ToolbarWrapper />
      <RackTypesListing isUserLoading={false} region={{
        id: undefined,
        name: undefined,
        avatar: undefined,
        email: undefined,
        position: undefined,
        role: undefined,
        last_login: undefined,
        two_steps: undefined,
        joined_day: undefined,
        online: undefined,
        region_name: undefined,
        metric_ind: undefined,
        model_year_plus_one_ind: undefined,
        initials: undefined,
        reference: undefined,
        note: undefined,
        rack_type_id: undefined,
        language: undefined,
        no_fit_ind: undefined
      }} />
    </>
  );
};

export { RackTypes };
