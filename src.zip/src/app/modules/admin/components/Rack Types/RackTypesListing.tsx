import { initialUser, Region } from "../Regions/core/_models";
import { FC, useEffect, useState } from "react";
import { getRegionListing } from "./core/_requests";
import { RackTypeAddModal } from "./RackTypeAddModal";

type Props = {
  isUserLoading: boolean;
  region: Region;
};

const RackTypesListing: FC<Props> = ({ region, isUserLoading }) => {
  const [regionListing, setRegionListing] = useState<[] | undefined>();

  //api consume for region listing
  useEffect(() => {
    async function getListingOfRegion() {
      try {
        let { data, status, message } = await getRegionListing();
        if (status === 200 && message == "Region List") {
          //populate data in array bjson
          setRegionListing(data);
        }
      } catch (error) {
        console.log("____________________________", error);
      }
    }
    getListingOfRegion();
  }, []);

  return (
    <>
      <div className="app-container container-fluid">
        <div className="card mb-5 mb-xl-10">
          <div id="kt_account_settings_notifications" className="">
            <div className="card card-custom">
              <div className="card-header border-0 pt-6">
                <div className="card-title"></div>
                <RackTypeAddModal
                  isUserLoading={false}
                  region={{
                    id: undefined,
                    name: undefined,
                    avatar: undefined,
                    email: undefined,
                    position: undefined,
                    role: undefined,
                    last_login: undefined,
                    two_steps: undefined,
                    joined_day: undefined,
                    online: undefined,
                    region_name: undefined,
                    metric_ind: undefined,
                    model_year_plus_one_ind: undefined,
                    initials: undefined,
                    reference: undefined,
                    note: undefined,
                    rack_type_id: undefined,
                    language: undefined,
                    no_fit_ind: undefined,
                  }}
                />
              </div>
            {/* table start here */}
              <div className="card-body py-4">
                <div className="table-responsive">
                  <table
                    id="kt_table_users"
                    className="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer"
                    role="table"
                  >
                    <thead>
                      <tr className="text-start fw-bolder fs-7 text-uppercase gs-0">
                        <th role="columnheader" className="min-w-125px">
                        Rack Type Name
                        </th>
                        <th role="columnheader" className="min-w-125px">
                        Rack Type Descriptions
                        </th>
                        <th role="columnheader" className="min-w-125px">
                          Allow Fits 
                        </th>
                      </tr>
                    </thead>
                    <tbody className="text-gray-600 fw-bold" role="rowgroup">
                      
                            <>
                              <tr role="row">
                                <td className="">
                                  <div className="d-flex align-items-center">
                                    <div
                                      className="d-flex flex-column"
                                      
                                    >
                                      Trunk
                                    </div>
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                  Test fit guide
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                    Test
                                  </div>
                                </td>
                              </tr>
                              <tr role="row">
                                <td className="">
                                  <div className="d-flex align-items-center">
                                    <div
                                      className="d-flex flex-column"
                                      
                                    >
                                      Trunk
                                    </div>
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                  Test fit guide
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                    Test
                                  </div>
                                </td>
                              </tr>
                              <tr role="row">
                                <td className="">
                                  <div className="d-flex align-items-center">
                                    <div
                                      className="d-flex flex-column"
                                      
                                    >
                                      Trunk
                                    </div>
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                  Test fit guide
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                    Test
                                  </div>
                                </td>
                              </tr>
                              <tr role="row">
                                <td className="">
                                  <div className="d-flex align-items-center">
                                    <div
                                      className="d-flex flex-column"
                                      
                                    >
                                      Trunk
                                    </div>
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                  Test fit guide
                                  </div>
                                </td>
                                <td>
                                  <div className="d-flex align-items-center">
                                    Test
                                  </div>
                                </td>
                              </tr>
                            </>
                         
                        
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export { RackTypesListing };
