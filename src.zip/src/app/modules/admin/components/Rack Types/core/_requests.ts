import axios, { AxiosResponse } from "axios";
import { ID, Response } from "../../../../../../_metronic/helpers";
import { Region, UsersQueryResponse } from "./_models";
import { REGION } from "../../../../../../util/constant";



const API_URL = import.meta.env.VITE_APP_THEME_API_URL;

const LOCAL_API_URL=import.meta.env.VITE_APP_THEME_LOCAL_API_URL;
const PREFIX = `admin/regions/`;
const REGION_URL = `${LOCAL_API_URL}/${PREFIX}`;
const REGION_BASE_URL=`${LOCAL_API_URL}`; 

const GET_USERS_URL = `${API_URL}/users/query`;

const getUsers = (query: string): Promise<UsersQueryResponse> => {
  return axios
    .get(`${GET_USERS_URL}?${query}`)
    .then((d: AxiosResponse<UsersQueryResponse>) => d.data);
};

const getUserById = (id: ID): Promise<Region | undefined> => {
  return axios
    .get(`${REGION_URL}/${id}`)
    .then((response: AxiosResponse<Response<Region>>) => response.data)
    .then((response: Response<Region>) => response.data);
};

const createUser = (notes: Region): Promise<Region | undefined> => {
  return axios
    .put(REGION_URL, notes)
    .then((response: AxiosResponse<Response<Region>>) => response.data)
    .then((response: Response<Region>) => response.data);
};

const updateUser = (user: Region): Promise<Region | undefined> => {
  return axios
    .post(`${REGION_URL}/${user.id}`, user)
    .then((response: AxiosResponse<Response<Region>>) => response.data)
    .then((response: Response<Region>) => response.data);
};

const deleteUser = (userId: ID): Promise<void> => {
  return axios.delete(`${REGION_URL}/${userId}`).then(() => {});
};

const deleteSelectedUsers = (userIds: Array<ID>): Promise<void> => {
  const requests = userIds.map((id) => axios.delete(`${REGION_URL}/${id}`));
  return axios.all(requests).then(() => {});
};

const createRegion = async (region: Region) => {
  try {
    
    let response = await axios.post(REGION_URL+REGION.ADD_REGION, region);
       console.log("____________________________________vehicle is here",response.data)
      return await response.data;
  } catch (error) {
    console.log("_______________________________________",error);
    throw error;
  }
};

//getRegionListing
const getRegionListing = async () => {
  try {
    const headers = {'Content-Type': 'application/json','Authorization': 'JWT fefege...'}
    let response = await axios.get(REGION_BASE_URL+"/find/"+REGION.REGION_LISTINGS,{
      headers:headers
    });
       console.log("____________________________________vehicle is here",response.data)
      return await response.data;
  } catch (error) {
    console.log("_______________________________________",error);
    throw error;
  }
};


export {
  getRegionListing,
  getUsers,
  deleteUser,
  deleteSelectedUsers,
  getUserById,
  createRegion,
  updateUser,
  createUser
};
