import { Button, Modal } from "react-bootstrap";
// import { KTIcon, SwalResponse } from "../../../../../../_metronic/helpers";
// import { useListView } from "../../core/ListViewProvider";
// import { MESSAGES } from "../../../../../../util/constant";
// import { initialUser, Vehicle } from "../../../../vehicles/model-list/core/_models";
// initialUser

import { FC, useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";

import { initialUser, Region } from "../../../admin/components/Regions/core/_models";
import { createRegion, getRegionListing } from "./core/_requests";
import { useQueryResponse } from "./core/QueryResponseProvider";
import clsx from "clsx";
//import { ModelListLoading } from "../loading/ModelListLoading";

import { KTIcon, SwalResponse } from "../../../../../_metronic/helpers";
import { useListView } from "../notes/note-list/core/ListViewProvider";
import { MESSAGES, REGION_LABEL } from "../../../../../util/constant";
import { RegionListing } from "./RegionListing";
import { useNavigate } from "react-router-dom";

// import { ModelListFilter } from "./ModelListFilter";

type Props = {
  isUserLoading: boolean;
  region: Region;
};

const AddModel = Yup.object().shape({
  region_name: Yup.string().max(500, 'Minimum value should be 500').required("region name is required"),
});

const RegionAddModal: FC<Props> = ({ region, isUserLoading }) => {
  const navigate=useNavigate();
  const [regionListing,setRegionListing]=useState<[] | undefined>();
  
  const { setItemIdForUpdate } = useListView();

  const [metric, setMetricInd] = useState<any | undefined>(false);
  const [modelYear, setModelYearPlus] = useState<any | undefined>(false);
  //const { refetch } = useQueryResponse();

  const [modelForVehicle] = useState<Region>({
    region_name: region.region_name || initialUser.region_name,
    // door_count: vehicle?.door_count || initialUser.door_count,
    // url: vehicle?.url || initialUser.url,
    // style: vehicle?.style || initialUser.style
  });

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // const openAddUserModals = () => {
  //   console.log("___________________________________________",setItemIdForUpdate)

  //     setItemIdForUpdate(null);
  // }

  // const cancel = (withRefresh?: boolean) => {
  //   if (withRefresh) {
  //     refetch();
  //   }
  //   setItemIdForUpdate(undefined);
  // };

  //form will be submit on event
  const formik = useFormik({
    initialValues: modelForVehicle,
    validationSchema: AddModel,
    onSubmit: async (values, { setSubmitting }) => {
      setSubmitting(true);
      try {
        let payload = {region_name:values.region_name,metric_ind:metric,model_year_plus_one_ind:modelYear};
   

        let result=await createRegion(payload);
        
        if (result?.status === 200 && result?.message == "Added successfully") {
          setShow(false);
          navigate("/admin/Regions")
          values.region_name="";
          setMetricInd(false)
          setModelYearPlus(false)
          SwalResponse('success', 'Region Added', MESSAGES.REGION_ADDED);
         
          //api call while submit the region page along with details
         let {data,status} = await getRegionListing();
         if(status==200) {setRegionListing(data);}
        } else {
          SwalResponse('error', 'warning', MESSAGES.SOMETHING_WENT_WRONG);
        }
      } catch (ex) {
        console.log("____________________________________ex is here",ex);
        
      } finally {
        setSubmitting(true);
        // cancel(true);
      }
    },
  });

  return (
    <>
      <Modal
        dialogClassName="popup-box mw-650px"
        backdrop="static"
        aria-labelledby="contained-modal-title-vcenter"
        centered
        show={show}
        onHide={handleClose}
        animation={false}
      >
        <Modal.Header>
          <h2 className="fw-bolder">Add Region</h2>
          <div onClick={() => setShow(false)}>
            <KTIcon iconName="cross" className="fs-1 cursor-pointer" />
          </div>
        </Modal.Header>

        <Modal.Body className="scroll-y mx-5 my-7">
        <form
        id="kt_modal_add_user_form"
        className="form"
        onSubmit={formik.handleSubmit}
        noValidate
      >
          <div className="fv-row mb-7">
            <label className="required fw-bold fs-6 mb-2">Name</label>
            <input type="text"
              {...formik.getFieldProps('region_name')}
              name="region_name"
              placeholder="Region Name"
              // className="form-control mb-3 mb-lg-0"
              className={clsx(
                'form-control mb-3 mb-lg-0',
                { 'is-invalid': formik.touched.region_name && formik.errors.region_name },
                {
                  'is-valid': formik.touched.region_name && !formik.errors.region_name,
                }
              )}
              disabled={formik.isSubmitting || isUserLoading}
            />

            {formik.touched.region_name && formik.errors.region_name && (
              <div className="fv-plugins-message-container">
                <div className="fv-help-block">
                  <span role="alert">{formik.errors.region_name}</span>
                </div>
              </div>
            )}

          </div>

          <div className="d-flex align-items-center">
            <label className="form-check form-check-custom form-check-inline form-check-solid me-5">

              <input className="form-check-input" name="communication[]" type="checkbox" onChange={(e) => setMetricInd(e.target.checked)} value={metric} checked={metric} />
              <span className="fw-semibold ps-2 fs-6">{REGION_LABEL.METRIC}</span></label>
            <label className="form-check form-check-custom form-check-inline form-check-solid me-5">

              <input className="form-check-input" name="communication[]" type="checkbox" readOnly onChange={(e) => setModelYearPlus(e.target.checked)} value={modelYear}  checked={modelYear} />
              <span className="fw-semibold ps-2 fs-6">{REGION_LABEL.MODEL_YEAR}</span>
            </label>
          </div>

          <div className='text-end pt-15'>
            <button
              type='reset'
              onClick={() => setShow(false)}
              className='btn btn-light me-3'
              data-kt-users-modal-action='cancel'
              disabled={formik.isSubmitting || isUserLoading}
            >
              Cancel
            </button>

            <button
            type="submit"
            className="btn btn-warning"
            data-kt-users-modal-action="submit"
            disabled={
              isUserLoading ||
              formik.isSubmitting ||
              !formik.isValid ||
              !formik.touched
            }
          >
            <span className="indicator-label">Submit</span>
            {(formik.isSubmitting || isUserLoading) && (
              <span className="indicator-progress">
                Please wait...{" "}
                <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
              </span>
            )}
          </button>
          </div>
          </form>
          {/* {(formik.isSubmitting || isUserLoading) && < />} */}

        </Modal.Body>
      </Modal>

      <div className="card-toolbar">
        <div
          className="d-flex justify-content-end"
          data-kt-user-table-toolbar="base"
        >
          <button
            onClick={handleShow}
            type="button"
            className="btn btn-warning"
          >
            <i className="ki-duotone ki-plus fs-2"></i>Add Region
          </button>
        </div>
      </div>
    </>
  );
};

export { RegionAddModal };
