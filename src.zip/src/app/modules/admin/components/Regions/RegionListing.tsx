import { RegionAddModal } from "./RegionAddModal";
import { initialUser, Region } from "../../../admin/components/Regions/core/_models";
import { FC, useEffect, useState } from "react";
import { getRegionListing } from "./core/_requests";
import { REGION } from "../../../../../util/constant";
import ReactPaginate from "react-paginate";
import { RegionListLoading } from "./components/loading/RegionListLoading";

type Props = {
    isUserLoading: boolean;
    region: Region;
};

const RegionListing: FC<Props> = ({ region, isUserLoading }) => {

    //paginate const define is here
    const [currentItems, setCurrentItems] = useState([]);
    const [pageCount, setPageCount] = useState(0);
    const [itemOffset, setItemOffset] = useState(0);
    const itemsPerPage = REGION.PAGINATE.ITEM_PER_PAGE;
    const [loading,setLoading]=useState(true);
    // end of paginate state

    const [regionListing, setRegionListing] = useState<[]>([]);

    //api consume for region listing
    useEffect(() => {
        async function getListingOfRegion() {
            try {
                let { data, status, message } = await getRegionListing();
                if (status === 200 && message == "Region List") {
                    //populate data in array bjson
                    setRegionListing(data);
                }
            } catch (error) {
                console.log("____________________________", error)
            }
        }
        getListingOfRegion();
    }, []);



    useEffect(() => {
        const endOffset = itemOffset + itemsPerPage;
        console.log(`Loading items from ${itemOffset} to ${endOffset}`);

        setCurrentItems(regionListing.slice(itemOffset, endOffset));
        setLoading(false)
        setPageCount(Math.ceil(regionListing.length / itemsPerPage));
    }, [itemOffset, itemsPerPage,regionListing])

    const handlePageClick = (event: any) => {
        const newOffset = event.selected * itemsPerPage % regionListing.length;
        console.log(`User requested page number ${event.selected}, which is offset ${newOffset}`);
        setItemOffset(newOffset);
    };


    return (
        <>
            <div className="app-container container-fluid">
                <div className="card mb-5 mb-xl-10">
                    <div id="kt_account_settings_notifications" className="">
                        <div className="card card-custom">
                            <div className="card-header border-0 pt-6">
                                <div className="card-title">

                                </div>
                                <RegionAddModal isUserLoading={false} region={{
                                    id: undefined,
                                    name: undefined,
                                    avatar: undefined,
                                    email: undefined,
                                    position: undefined,
                                    role: undefined,
                                    last_login: undefined,
                                    two_steps: undefined,
                                    joined_day: undefined,
                                    online: undefined,
                                    region_name: undefined,
                                    metric_ind: undefined,
                                    model_year_plus_one_ind: undefined,
                                    initials: undefined,
                                    reference: undefined,
                                    note: undefined,
                                    rack_type_id: undefined,
                                    language: undefined,
                                    no_fit_ind: undefined
                                }} />
                            </div>

                            <div className="card-body py-4">
                                <div className="table-responsive">
                                    <table id="kt_table_users" className="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer" role="table">
                                        <thead>
                                            <tr className="text-start fw-bolder fs-7 text-uppercase gs-0">
                                                <th role="columnheader" className="min-w-125px">Region</th>
                                                <th role="columnheader" className="min-w-125px">Metric</th>
                                                <th role="columnheader" className="min-w-125px">Plus One</th>
                                            </tr>
                                        </thead>
                                        <tbody className="text-gray-600 fw-bold" role="rowgroup">
                                            {
                                              loading ? <RegionListLoading/> :  currentItems && currentItems?.map((val: { region_name: string, region_id: number, metric_ind: boolean, model_year_plus_one_ind: boolean }, index) => (
                                                    <>
                                                        <tr role="row">
                                                            <td className="">
                                                                <div className="d-flex align-items-center">
                                                                    <div className="d-flex flex-column" key={val?.region_id}>{val?.region_name || 'N/A'}</div></div>
                                                            </td>
                                                            <td>
                                                                <div className="d-flex align-items-center">
                                                                    <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                                                                        <input className="form-check-input" checked={val?.metric_ind} name="communication[]" type="checkbox" value={+val?.metric_ind} />
                                                                    </label>
                                                                </div>
                                                            </td>
                                                            <td><div className="d-flex align-items-center">
                                                                <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                                                                    <input className="form-check-input" name="communication[]" checked={val?.model_year_plus_one_ind} type="checkbox" value={+val?.model_year_plus_one_ind} />
                                                                </label>
                                                            </div></td>
                                                        </tr>
                                                    </>
                                                ))
                                            }

                                        </tbody>
                                    </table>
                                </div>
                            </div>

                        {
                            loading==false &&  <>
                            <ReactPaginate
                                    nextLabel="NEXT >"
                                    onPageChange={(event) => handlePageClick(event)}
                                    pageRangeDisplayed={3}
                                    marginPagesDisplayed={2}
                                    pageCount={pageCount}
                                    previousLabel="< PREVIOUS"
                                    pageClassName="page-item"
                                    pageLinkClassName="page-link"
                                    previousClassName="page-item"
                                    previousLinkClassName="page-link"
                                    nextClassName="page-item"
                                    nextLinkClassName="page-link"
                                    breakLabel="..."
                                    breakClassName="page-item"
                                    breakLinkClassName="page-link"
                                    containerClassName="pagination"
                                    activeClassName="active"
                                    renderOnZeroPageCount={null} />
                                    <div>Total Record: {regionListing?.length || 0}</div>
                                    </>
                        }
                            

                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export { RegionListing };