import { FC } from "react";
import Select from "react-select";
import {
  StatisticsWidget1,
  StatisticsWidget2,
  StatisticsWidget3,
  StatisticsWidget4,
  StatisticsWidget5,
  StatisticsWidget6,
} from "../../../../../_metronic/partials/widgets";
import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { Content } from "../../../../../_metronic/layout/components/content";

const AddNewRegions: FC = () => {
  return (
    <>
      <ToolbarWrapper />
      <Content>
        <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
          
          
        </div>

       

        <div className="mb-5 mb-xl-10">
         
          <div className="d-flex">
            <button type="submit" id="kt_ecommerce_add_product_submit" className="btn btn-warning">
              <span className="indicator-label">Submit</span></button>
          </div>
      
          </div>


      </Content>
    </>
  );
};

export { AddNewRegions };
