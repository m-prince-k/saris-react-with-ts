import { FC } from "react";
// import {
//   ListsWidget1,
//   ListsWidget2,
//   ListsWidget3,
//   ListsWidget4,
//   ListsWidget5,
//   ListsWidget6,
//   ListsWidget7,
//   ListsWidget8,
// } from "../../../../_metronic/partials/widgets";



import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { Link } from "react-router-dom";
// import { RegionEditModal } from "./region-edit-model/regionEditModal";
// import { Content } from "../../../../_metronic/layout/components/content";
// import { Link } from "react-router-dom";
// import { Routes, Route, BrowserRouter, Navigate } from "react-router-dom";

const Settings: FC = () => {
  return (
    <>
      <ToolbarWrapper />
      <div className="app-container container-fluid">
        <div className="card mb-5 mb-xl-10">
          <div id="kt_account_settings_notifications" className="">
            <div className="card card-custom">
            <div className="card-header border-0 pt-6">
    <div className="card-title">
    <h3 className="text-gray-800  fs-2 fw-bolder me-1">Settings</h3> 
    </div>
    {/* <div className="card-toolbar">

   <div className="d-flex justify-content-end" data-kt-user-table-toolbar="base">
            <button type="button" className="btn btn-warning"><i className="ki-duotone ki-plus fs-2"></i>Add Region</button>
        </div>
    </div> */}
</div>

            <div className="card-body py-4">
            
</div>
            </div>
          </div>
        </div>

        

       
      </div>
    </>
  );
};

export { Settings };
