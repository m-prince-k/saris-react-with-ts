import { ListViewProvider, useListView } from "./core/ListViewProvider";
import { QueryRequestProvider } from "./core/QueryRequestProvider";
import { QueryResponseProvider } from "./core/QueryResponseProvider";
import { NoteListHeader } from "./components/header/NoteListHeader";

import { NoteEditModal } from "./note-edit-modal/NoteEditModal";
import { KTCard } from "../../../../../../_metronic/helpers";
import { ToolbarWrapper } from "../../../../../../_metronic/layout/components/toolbar";
import { Content } from "../../../../../../_metronic/layout/components/content";
import { PageTitle } from "../../../../../../_metronic/layout/core";
import NoteTable from "./table/NoteTable";

const NoteList = () => {
  const { itemIdForUpdate } = useListView();
  return (
    <>
      <KTCard>
        {/* <PageTitle breadcrumbs={[]}>Vehicles</PageTitle> */}
        <NoteListHeader />
        <NoteTable />
      </KTCard>
      {itemIdForUpdate !== undefined && <NoteEditModal />}
    </>
  );
};

const NoteListWrapper = () => (
  <QueryRequestProvider>
    <QueryResponseProvider>
      <ListViewProvider>
        <ToolbarWrapper />
        <Content>
          <NoteList />
        </Content>
      </ListViewProvider>
    </QueryResponseProvider>
  </QueryRequestProvider>
);

export { NoteListWrapper };
