import { useListView } from "../../core/ListViewProvider";
import { NoteListToolbar } from "./NoteListToolbar";
import { NoteListGrouping } from "./NoteListGrouping";
import { NoteListSearchComponent } from "./NoteListSearchComponent";

const NoteListHeader = () => {
  const { selected } = useListView();
  return (
    <>
      <div className="card-header border-0 pt-6">
        <NoteListSearchComponent />

        <div className="card-toolbar">
          {selected.length > 0 ? <NoteListGrouping /> : <NoteListToolbar />}
        </div>
      </div>

      {/* <div className="filter-main">
        <ul>
          <li className="f-active"> All</li>
          <li>A </li>
          <li> B </li>
          <li> C</li>
          <li> D</li>
          <li> E </li>
          <li> F </li>
          <li> G </li>
          <li> H</li>
          <li>I</li>
          <li> J </li>
          <li> K</li>
          <li> L </li>
          <li> M</li>
          <li> N </li>
          <li> O</li>
          <li> P</li>
          <li> Q</li>
          <li> R </li>
          <li> S</li>
          <li> T</li>
          <li> U </li>
          <li> V </li>
          <li> W</li>
          <li>X</li>
          <li> Y</li>
          <li> Z</li>
        </ul>
      </div> */}
    </>
  );
};

export { NoteListHeader };
