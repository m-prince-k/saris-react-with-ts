import { ID, Response } from "../../../../../../../_metronic/helpers";
export type Notes = {
  
  id?: ID;
  note_id?:string;
  name?: string;
  avatar?: string;
  email?: string;
  position?: string;
  role?: string;
  last_login?: string;
  two_steps?: boolean;
  joined_day?: string;
  online?: boolean;
  initials?: {
    label: string;
    state: string;
  };
  reference?:number,
  note?:string,
  rack_type_id?:number,
  language?:string,
  no_fit_ind?:boolean
};

export type UsersQueryResponse = Response<Array<Notes>>;

export const initialUser: Notes = {
  avatar: "avatars/300-6.jpg",
  position: "Art Director",
  role: "Administrator",
  reference:0,
  note:'',
  rack_type_id:0,
  language:'',
  no_fit_ind:false,
  note_id:''
};
