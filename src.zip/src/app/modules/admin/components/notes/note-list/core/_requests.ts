import axios, { AxiosResponse } from "axios";
import { ID, Response } from "../../../../../../../_metronic/helpers";
import { Notes, UsersQueryResponse } from "./_models";
import { ADMIN, RACK_ADMIN } from "../../../../../../../util/constant";

const API_URL = import.meta.env.VITE_APP_THEME_API_URL;

const LOCAL_API_URL=import.meta.env.VITE_APP_THEME_LOCAL_API_URL;
const PREFIX = `admin/notes/`;
const NOTES_URL = `${LOCAL_API_URL}/${PREFIX}`;

const GET_USERS_URL = `${API_URL}/users/query`;

const getUsers = (query: string): Promise<UsersQueryResponse> => {
  return axios
    .get(`${GET_USERS_URL}?${query}`)
    .then((d: AxiosResponse<UsersQueryResponse>) => d.data);
};

const getUserById = (id: ID): Promise<Notes | undefined> => {
  return axios
    .get(`${NOTES_URL}/${id}`)
    .then((response: AxiosResponse<Response<Notes>>) => response.data)
    .then((response: Response<Notes>) => response.data);
};

const createUser = (notes: Notes): Promise<Notes | undefined> => {
  return axios
    .put(NOTES_URL, notes)
    .then((response: AxiosResponse<Response<Notes>>) => response.data)
    .then((response: Response<Notes>) => response.data);
};

const updateUser = (user: Notes): Promise<Notes | undefined> => {
  return axios
    .post(`${NOTES_URL}/${user.note_id}`, user)
    .then((response: AxiosResponse<Response<Notes>>) => response.data)
    .then((response: Response<Notes>) => response.data);
};

const deleteUser = (userId: ID): Promise<void> => {
  return axios.delete(`${NOTES_URL}/${userId}`).then(() => {});
};

const deleteSelectedUsers = (userIds: Array<ID>): Promise<void> => {
  const requests = userIds.map((id) => axios.delete(`${NOTES_URL}/${id}`));
  return axios.all(requests).then(() => {});
};


const createNotes = async (notes: Notes) => {
  try {
    
    let response = await axios.post(NOTES_URL+ADMIN.NOTES.ADD_NEW_NOTE, notes);
       console.log("____________________________________vehicle is here",response.data)
      return await response.data;
  } catch (error) {
    console.log("_______________________________________",error);
    throw error;
  }
};



const getLanguage = async () => {
  try {
    let response = await axios.get(NOTES_URL + ADMIN.NOTES.LANGUAGES);
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}

const getRackTypes = async () => {
  try {
    let response = await axios.get(LOCAL_API_URL + "/admin/racks/" + RACK_ADMIN.GET_RACKS_TYPE);
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}


//get note listing
const getNoteListing = async () => {
  try {
    const headers = {'Content-Type': 'application/json','Authorization': 'JWT fefege...'}
    let response = await axios.get("http://192.168.3.67:3000/api/admin/notes/" + ADMIN.NOTES.GET_NOTES,{
      headers:headers
    });
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}


export {
  getNoteListing,
  getRackTypes,
  getLanguage,
  getUsers,
  deleteUser,
  deleteSelectedUsers,
  getUserById,
  createNotes,
  updateUser,
  createUser
};
