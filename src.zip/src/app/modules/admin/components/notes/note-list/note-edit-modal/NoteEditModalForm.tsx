import { FC, useEffect, useState } from "react";
import * as Yup from "yup";
import { useFormik } from "formik";
import {
  isNotEmpty,
  SwalResponse,
  toAbsoluteUrl,
} from "../../../../../../../_metronic/helpers";
import { initialUser, Notes } from "../../../notes/note-list/core/_models";
import clsx from "clsx";
import { useListView } from "../core/ListViewProvider";
import { NoteListLoading } from "../components/loading/NoteListLoading";
import {
  createNotes,
  createUser,
  getLanguage,
  getRackTypes,
} from "../core/_requests";
import { useQueryResponse } from "../core/QueryResponseProvider";
import Select from "react-select";
import { MESSAGES } from "../../../../../../../util/constant";

type Props = {
  isUserLoading: boolean;
  notes: Notes;
};

const editUserSchema = Yup.object().shape({
  reference: Yup.string()
    .max(2, "Maximum 2 symbols")
    .required("Please enter the reference"),
  note: Yup.string()
    .max(500, "Maximum 2 symbols")
    .required("Please enter the note"),
});

const NoteEditModalForm: FC<Props> = ({ notes, isUserLoading }) => {
  const { setItemIdForUpdate } = useListView();
  const { refetch } = useQueryResponse();
  const [error, setError] = useState("");

  const [rackType, setRackType] = useState<any | undefined>({
    label: "Rack Type",
    value: "Rack Type",
  });

  const [populateLang, setPopulateLang] = useState<any | undefined>([]);
  const [populateRacks, setPopulateRacks] = useState<any | undefined>([]);
  const [language, setLanguage] = useState<any | undefined>({
    value: "EN-US",
    label: "EN-US",
  });

  const [fitAssories, fitAssoriesChange] = useState<any | undefined>();

  const rackTypeChange = (e: any) => {
    if (rackType.value != "") {
      setError("");
    }
    if (e.value) {
      setRackType({ value: e.value, label: e.label });
    }
  };

  //auto populate langauge api consume here
  useEffect(() => {
    async function callAccessType() {
      let { data } = await getLanguage();
      console.log("language is here________________________", data);

      const options2 = await data.map(
        (d: { value: number; label: string }) => ({
          value: d.value,
          label: d.label,
        })
      );
      setPopulateLang(options2);
    }

    //call the rack type is here

    async function callRackTypes() {
      let { data } = await getRackTypes();
      console.log("rack type is here________________________", data);

      const options2 = await data.map(
        (d: { rack_type_id: number; rack_type_name: string }) => ({
          value: d.rack_type_id,
          label: d.rack_type_name,
        })
      );
      setPopulateRacks(options2);
    }

    callAccessType();
    callRackTypes();
  }, []);
  //end of language api consume
  const setLanguageHandleBar = (e: any) => {
    if (e.value) setLanguage({ value: e.value, label: e.label });
  };
  const fitHandleChange = (e: any) => {
    if (e.target.checked == true) {
      fitAssoriesChange(1);
    } else if (e.target.checked == false) {
      fitAssoriesChange(0);
    }
  };

  const [userForEdit] = useState<Notes>({
    ...notes,
    reference: notes?.reference || initialUser.reference,
    note: notes?.note || initialUser.note,
    rack_type_id: notes?.rack_type_id || initialUser.rack_type_id,
    language: notes?.language || initialUser.language,
    no_fit_ind: notes?.no_fit_ind || initialUser.no_fit_ind,
  });

  const cancel = (withRefresh?: boolean) => {
    if (withRefresh) {
      refetch();
    }
    setItemIdForUpdate(undefined);
  };

  // const blankImg = toAbsoluteUrl("media/svg/avatars/blank.svg");
  // const userAvatarImg = toAbsoluteUrl(`media/${userForEdit.avatar}`);

  const formik = useFormik({
    initialValues: userForEdit,
    validationSchema: editUserSchema,
    onSubmit: async (values, { setSubmitting }) => {
      console.log(
        "___________________________________values is here",
        rackType.value
      );
      var errorStatus = false;
      if (rackType.value == "Rack Type") {
        setError("Please select the rack type");
        errorStatus = false;
      } else {
        errorStatus = true;
        setError("");
        setSubmitting(true);

        try {
          console.log(
            "_____________________________________payload is here",
            values
          );

          let { value } = rackType;
          let _language = language.value;
          let payload = {
            reference: values.reference,
            note: values.note,
            rack_type_id: value,
            language: _language,
            no_fit_ind: Boolean(fitAssories),
          };

          let result = await createNotes(payload);

          if (
            result?.status === 200 &&
            result?.message == "Added successfully"
          ) {
            SwalResponse("success", "Added", MESSAGES.NOTES_ADDED);
          } else {
            SwalResponse("error", "warning", MESSAGES.SOMETHING_WENT_WRONG);
          }

          // if (isNotEmpty(values.id)) {
          //   await updateUser(values);
          // } else {
          //   await createUser(values);
          // }
        } catch (ex) {
          console.error(ex);
        } finally {
          setSubmitting(true);
          cancel(true);
        }
      }
    },
  });

  return (
    <>
      <form
        id="kt_modal_add_user_form"
        className="form"
        onSubmit={formik.handleSubmit}
        noValidate
      >
        <div
          className="d-flex flex-column scroll-y me-n7 pe-5"
          id="kt_modal_add_user_scroll"
          data-kt-scroll="true"
          data-kt-scroll-activate="{default: false, lg: true}"
          data-kt-scroll-max-height="auto"
          data-kt-scroll-dependencies="#kt_modal_add_user_header"
          data-kt-scroll-wrappers="#kt_modal_add_user_scroll"
          data-kt-scroll-offset="300px"
        >
          <div className="fv-row mb-7">
            <label className="fw-bold fs-6 mb-2">Reference</label>

            <input
              placeholder="00"
              {...formik.getFieldProps("reference")}
              min={1}
              type="number"
              name="reference"
              className={clsx(
                "form-control mb-3 mb-lg-0",
                {
                  "is-invalid":
                    formik.touched.reference && formik.errors.reference,
                },
                {
                  "is-valid":
                    formik.touched.reference && !formik.errors.reference,
                }
              )}
              autoComplete="off"
            />
            {formik.touched.reference && formik.errors.reference && (
              <div className="fv-plugins-message-container">
                <div className="fv-help-block">
                  <span role="alert">{formik.errors.reference}</span>
                </div>
              </div>
            )}
          </div>

          <div className="fv-row w-100 flex-md-root fv-plugins-icon-container mb-7 ">
            <label className="required form-label">Rack Type</label>
            <Select
              {...formik.getFieldProps("rack_type_id")}
              name="rack_type_id"
              className="mb-2 select2-hidden-accessible sel-box"
              placeholder="Select Rack Type"
              onChange={rackTypeChange}
              value={rackType}
              options={populateRacks}
            />
            <span className="text-danger">{error}</span>
          </div>
          <div className="fv-row w-100 flex-md-root fv-plugins-icon-container mb-7 ">
            <label className="required form-label">Language</label>
            <Select
              {...formik.getFieldProps("language")}
              name="language"
              className="mb-2 select2-hidden-accessible sel-box"
              placeholder="Select Language"
              onChange={setLanguageHandleBar}
              value={language}
              options={populateLang}
              //defaultValue={value:e.value,label:e.label}
            />
          </div>

          <div className="fv-row w-100 flex-md-root fv-plugins-icon-container mb-7 ">
            <label className="required form-label">Accessories</label>
            <div className="d-flex align-items-center">
              <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                <input
                  {...formik.getFieldProps("no_fit_ind")}
                  className="form-check-input"
                  name="no_fit_ind[]"
                  onChange={fitHandleChange}
                  type="checkbox"
                  checked={fitAssories || ""}
                  value={fitAssories || ""}
                />

                <span className="fw-semibold ps-2 fs-6">No Fit</span>
              </label>
            </div>
          </div>

          <div className="fv-row mb-7">
            <label className="required fw-bold fs-6 mb-2">Note</label>

            <textarea
              {...formik.getFieldProps("note")}
              name="note"
              placeholder="Comments"
              className="form-control mb-3 mb-lg-0"
            ></textarea>
          </div>

          <div className="fv-row mb-7">
            <label className="fw-bold fs-6 mb-2">NOTE:</label>

            <p>
              You cannot edit which accessories are linked to this note via the
              web application. Contact a database administrator to edit the
              values directly in the database.
            </p>
          </div>
        </div>

        <div className="text-end pt-10">
          <button
            type="reset"
            onClick={() => cancel()}
            className="btn btn-light me-3"
            data-kt-users-modal-action="cancel"
            disabled={formik.isSubmitting || isUserLoading}
          >
            Discard
          </button>

          <button
            type="submit"
            className="btn btn-warning"
            data-kt-users-modal-action="submit"
            disabled={
              isUserLoading ||
              formik.isSubmitting ||
              !formik.isValid ||
              !formik.touched
            }
          >
            <span className="indicator-label">Submit</span>
            {(formik.isSubmitting || isUserLoading) && (
              <span className="indicator-progress">
                Please wait...{" "}
                <span className="spinner-border spinner-border-sm align-middle ms-2"></span>
              </span>
            )}
          </button>
        </div>
        {/* end::Actions */}
      </form>
      {(formik.isSubmitting || isUserLoading) && <NoteListLoading />}
    </>
  );
};

export { NoteEditModalForm };
