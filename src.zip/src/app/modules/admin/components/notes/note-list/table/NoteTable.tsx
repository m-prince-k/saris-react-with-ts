import React, { useState, useEffect } from 'react';

import { getNoteListing } from '../core/_requests';
import { ADMIN } from "../../../../../../../util/constant";
import { CustomReactPaginate, KTCardBody } from '../../../../../../../_metronic/helpers';
import { NoteListLoading } from '../components/loading/NoteListLoading';
import ReactPaginate from 'react-paginate';

export default function NoteTable() {

  const [currentItems, setCurrentItems] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);
  const itemsPerPage=ADMIN.NOTES.PAGINATE.ITEM_PER_PAGE;
  const [notes,setNotes]=useState<[]>([]);
  const [loading,setLoading]=useState(true)

  useEffect(() => {
    async function getListingOfNotes() {
      try {
        let { data, status, message } = await getNoteListing();
        if (status === 200 && message == "Notes List") {
          setNotes(data);
        }
      } catch (error) {
        console.log("______________________________________", error)
        throw error;
      }
    }
    getListingOfNotes();
  }, [])
    
    useEffect(() => {
       const {currentItem,pageCount}=CustomReactPaginate(notes,itemOffset,itemsPerPage);
      setCurrentItems(currentItem);
      currentItem && setLoading(false)
      setPageCount(pageCount);
    }, [itemOffset, itemsPerPage,notes]);

    const handlePageClick = (event: any) => {
      const newOffset = event.selected * itemsPerPage % notes.length;
      console.log(`User requested page number ${event.selected}, which is offset ${newOffset}`);
      setItemOffset(newOffset);
    };


    return (
      <KTCardBody className="py-4">
      <div className="card-body py-4">
        <div className="table-responsive">
          <table
            id="kt_table_users"
            className="table align-middle table-row-dashed fs-6 gy-5 dataTable no-footer"
            role="table"
          >
            <thead>
              <tr className="text-start fw-bolder fs-7 text-uppercase gs-0">
                <th role="columnheader" className="min-w-125px">
                  Reference
                </th>
                <th role="columnheader" className="min-w-125px">
                  Note
                </th>
                <th role="columnheader" className="min-w-125px">
                  Rack Type
                </th>
                <th role="columnheader" className="min-w-125px">
                  Language
                </th>
                <th role="columnheader" className="min-w-125px">
                  Action
                </th>
                
              </tr>
            </thead>
            <tbody className="text-gray-600 fw-bold" role="rowgroup">
              {
                loading ? <NoteListLoading /> : currentItems && currentItems?.map((val:{reference:string,note:string,rack_type:{rack_type_name:string},language:string}) => (
                  <>
                    <tr role="row">
                      <td className="">
                        <div className="d-flex align-items-center">
                          <div className="d-flex flex-column">{val?.reference || 'N/A'}</div>
                        </div>
                      </td>

                      <td className="">
                        <div className="d-flex align-items-center">
                          <div className="d-flex flex-column">{val?.note || 'N/A'}</div>
                        </div>
                      </td>


                      <td className="">
                        <div className="d-flex align-items-center">
                        <div className="d-flex flex-column">{val?.rack_type?.rack_type_name || 'N/A'}</div>
                        </div>
                      </td>



                      <td className="">
                        <div className="d-flex align-items-center">
                        <div className="d-flex flex-column">{val?.language || 'N/A'}</div>
                        </div>
                      </td>

                      <td className="">
                        <div className="d-flex align-items-center">
                        <select>
                          <option>Edit</option>
                          <option>Delete</option>
                        </select>
                        </div>
                      </td>
                    </tr>
                  </>
                ))
              }



            </tbody>
          </table>
        </div>
      </div>

      
      {
        loading==false && 
        <ReactPaginate
      nextLabel="NEXT >"
      onPageChange={(event) => handlePageClick(event)}
      pageRangeDisplayed={3}
      marginPagesDisplayed={2}
      pageCount={pageCount}
      previousLabel="< PREVIOUS"
      pageClassName="page-item"
      pageLinkClassName="page-link"
      previousClassName="page-item"
      previousLinkClassName="page-link"
      nextClassName="page-item"
      nextLinkClassName="page-link"
      breakLabel="..."
      breakClassName="page-item"
      breakLinkClassName="page-link"
      containerClassName="pagination"
      activeClassName="active"
      renderOnZeroPageCount={null}
    /> 
   
      }
       Total Record: {loading==false ?  notes?.length || 0 : 0}


    </KTCardBody>
    );
}
        