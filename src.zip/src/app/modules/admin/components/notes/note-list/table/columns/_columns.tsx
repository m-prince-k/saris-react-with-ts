import { Column } from "react-table";
import { NoteInfoCell } from "./NoteInfoCell";
import { NoteLastLoginCell } from "./NoteLastLoginCell";
import { NoteTwoStepsCell } from "./NoteTwoStepsCell";
import { NoteActionsCell } from "./NoteActionsCell";
import { NoteSelectionCell } from "./NoteSelectionCell";
import { NoteCustomHeader } from "./NoteCustomHeader";
import { NoteSelectionHeader } from "./NoteSelectionHeader";
import { Notes } from "../../core/_models";

const usersColumns: ReadonlyArray<Column<Notes>> = [
  // {
  //   Header: (props) => <NoteSelectionHeader tableProps={props} />,
  //   Cell: ({ ...props }) => (
  //     <NoteSelectionCell id={props.data[props.row.index].id} />
  //   ),
  // },
  // {
  //   Header: (props) => (
  //     <NoteCustomHeader
  //       tableProps={props}
  //       title="Ref"
  //       className="min-w-125px"
  //     />
  //   ),
  //   id: "name",
  //   Cell: ({ ...props }) => <NoteInfoCell note={props.data[props.row.index]} />,
  // },
  {
    Header: (props) => (<NoteCustomHeader tableProps={props} title="Note" className="min-w-125px"/>),
    // accessor: "role",
    id: "note",
      Cell: ({ ...props }) => (
       
      <NoteLastLoginCell last_login={props.data[props.row.index].note} />
    ),    
  },
  // {
  //   Header: (props) => (
  //     <NoteCustomHeader
  //       tableProps={props}
  //       title="Rack Type"
  //       className="min-w-125px"
  //     />
  //   ),
  //   id: "last_login",
  //   Cell: ({ ...props }) => (
  //     <NoteLastLoginCell last_login={props.data[props.row.index].last_login} />
  //   ),
  // },

  // {
  //   Header: (props) => (
  //     <NoteCustomHeader
  //       tableProps={props}
  //       title="Lang"
  //       className="min-w-125px"
  //     />
  //   ),
  //   id: "two_steps",
  //   Cell: ({ ...props }) => (
  //     <NoteTwoStepsCell two_steps={props.data[props.row.index].two_steps} />
  //   ),
  // },
  // {
  //   Header: (props) => (
  //     <NoteCustomHeader
  //       tableProps={props}
  //       title="Access"
  //       className="min-w-125px"
  //     />
  //   ),
  //   accessor: "joined_day",
  // },
  // {
  //   Header: (props) => (
  //     <NoteCustomHeader
  //       tableProps={props}
  //       title="Actions"
  //       className="text-end min-w-100px"
  //     />
  //   ),
  //   id: "actions",
  //   Cell: ({ ...props }) => (
  //     <NoteActionsCell id={props.data[props.row.index].id} />
  //   ),
  // },
];

export { usersColumns };
