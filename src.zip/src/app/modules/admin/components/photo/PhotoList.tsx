import { KTCard } from "../../../../../_metronic/helpers";
import { Content } from "../../../../../_metronic/layout/components/content";
import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { NoteListHeader } from "../notes/note-list/components/header/NoteListHeader";
import { useListView } from "../notes/note-list/core/ListViewProvider";
import { NoteEditModal } from "../notes/note-list/note-edit-modal/NoteEditModal";
// import { NoteTable } from "../notes/note-list/table/NoteTable";


const PhotoList = () => {
  const { itemIdForUpdate } = useListView();
  return (
    <>
      <KTCard>
        {/* <PageTitle breadcrumbs={[]}>Vehicles</PageTitle> */}
      This is new photo edit component dfzdfzgz
       
      </KTCard>
      {itemIdForUpdate !== undefined && <NoteEditModal />}
    </>
  );
};

const PhotoListWrapper = () => (
    <>
     <ToolbarWrapper />
        <Content>
          <PhotoList />
        </Content>
    </>
);

export { PhotoListWrapper };
