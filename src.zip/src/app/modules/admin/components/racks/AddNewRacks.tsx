import Select from "react-select";
import { FC, useEffect, useState } from "react";
import * as Yup from "yup";
import { setIn, useFormik } from "formik";
import { initialUser, Rack } from "../../../admin/components/racks/core/_models";
import { createCustomRack, getRackTypes, getRackReceiver, getRackSupport } from "./core/_requests";

import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { Content } from "../../../../../_metronic/layout/components/content";
import { SwalResponse } from "../../../../../_metronic/helpers";
import { MESSAGES } from "../../../../../util/constant";
import { useNavigate } from "react-router-dom";

import clsx from "clsx";


type Props = {
  isUserLoading: boolean;
  rack: Rack;
};

const AddModel = Yup.object().shape({

  // rack_type_id: Yup
  //   .object()
  //   .shape({
  //     label: Yup.string().required("status is required (from label)"),
  //     value: Yup.string().required("status is required")
  //   })
  //   .nullable() // for handling null value when clearing options via clicking "x"
  //   .required("status is required (from outter null check)"),

  name: Yup.string().max(500, 'Minimum value should be 500').required("Please enter the rack name"),
  rack_number: Yup.string().max(200, 'Minimum value should be 500').required("Please enter the rack number"),
  max_bikes: Yup.string().max(1, 'Minimum value should be 1'),
  fit_guide_column: Yup.string().matches(/^[0-9]*$/, 'Only number allowd').max(3, 'maximum value should be 3'),
});



const AddNewRacks: FC<Props> = ({ rack, isUserLoading }) => {
  const navigate = useNavigate();
  const [types, setTypes] = useState([]);
  const [support, setSupport] = useState([]);
  const [error1, error11] = useState("");
  const [error2, error22] = useState("");
  const [error3, error33] = useState("");

  const [reciever, setReciever] = useState([]);

  const [rackType, setRackType] = useState<any | undefined>({ value: "Rack Type", label: "Rack Type" });

  const [typeeError, setError] = useState<any | undefined>();
  const [supportError, setSupprotError] = useState<any | undefined>();
  const [recieverError, setRecieverError] = useState<any | undefined>();

  const [rackSupport, setRackSupport] = useState<any | undefined>({ value: 0, label: "Rack Support Style" })
  const [revieverClass, reciverSetClass] = useState<any | undefined>({ value: 0, label: "Receiver Class" });

  const handleChangeRack = (e: any, support: string) => {
    if (support == "racktype") {
      if (rackType.value != "") { error11("") }
      setRackType({ value: e.value, label: e.label })
    } else if (support == "racksupport") {
      if (rackSupport.value != "") { error22("") }
      setRackSupport({ value: e.value, label: e.label })
    } else if (support == "recieverclass") {
      if (revieverClass.value != "") { error33("") }
      reciverSetClass({ value: e.value, label: e.label })
    }
    else if (support == "recieverclass") { reciverSetClass({ value: e.value, label: e.label }) }
  }


  useEffect(() => {
    //support auto populate start here
    async function callTypes() {
      let { data } = await getRackTypes();
      const options = await data.map((d: { rack_type_id: any, rack_type_name: any }) => ({
        "value": d.rack_type_id,
        "label": d.rack_type_name
      }));
      setTypes(options);
    }
    //support auto populate start here
    async function callSupport() {
      let { data } = await getRackSupport();

      const options1 = await data.map((d: { rack_support_style_id: any, rack_support_style_name: any }) => ({
        "value": d.rack_support_style_id,
        "label": d.rack_support_style_name
      }));
      setSupport(options1);
    }
    //receiver auto populate start here
    async function callReceiver() {
      let { data } = await getRackReceiver();
      const options2 = await data.map((d: { receiver_class_id: any, receiver_class_name: any }) => ({
        "value": d.receiver_class_id,
        "label": d.receiver_class_name
      }));
      setReciever(options2);
    }

    callTypes();
    callSupport();
    callReceiver();
  }, [])

  const [inputField, setInputFields] = useState<any | undefined>({
    obsolete: '',
    tiltsRacks: false,
    heavy_bikes_Racks: false,
    feet_spoiler: false,
    use_rack_saddle_to_ground: false,
    use_trunk_opens_with_clips_ind: false,
    use_rack_saddle_to_license: false,
    use_arm_position: false,
    use_leg_position: false,
    use_arm_angle: false,
    use_top_feet_spoiler_location_id: false,
    use_rack_location_id: false,
    use_top_strap_location_id: false,
    use_bottom_strap_location_id: false,
    use_bottom_feet_surface_id: false,
    use_position_with_spoiler: false,
    use_lower_feet_to_crossbar: false,
    use_lower_feet_location_id: false,
    use_position_without_spoiler: false
  });


  const [modelForVehicle] = useState<Rack>({
    name: rack?.name || initialUser.name,
    rack_number: rack?.rack_number || initialUser.rack_number,
    obsolete_ind: rack?.obsolete_ind || initialUser.obsolete_ind,
    rack_type_id: rack?.rack_type_id || initialUser.rack_type_id,
    rack_support_style_id: rack?.rack_support_style_id || initialUser.rack_support_style_id,
    receiver_class_id: rack?.receiver_class_id || initialUser.receiver_class_id,
    max_bikes: rack?.max_bikes || initialUser.max_bikes,
    tilts: rack?.tilts || initialUser.tilts,
    heavy_bike_ind: rack?.heavy_bike_ind || initialUser.heavy_bike_ind,
    fit_guide_column: rack?.fit_guide_column || initialUser.fit_guide_column,
    fit_guide_group: rack?.fit_guide_group || initialUser.fit_guide_group,
    rack_overview: rack?.rack_overview || initialUser.rack_overview,


    //option set for further for along with racks detail
    use_rack_saddle_to_ground: rack?.use_rack_saddle_to_ground || initialUser.use_rack_saddle_to_ground,
    use_trunk_opens_with_clips_ind: rack?.use_trunk_opens_with_clips_ind || initialUser.use_trunk_opens_with_clips_ind,
    use_rack_saddle_to_license: rack?.use_rack_saddle_to_license || initialUser.use_rack_saddle_to_license,
    use_arm_position: rack?.use_arm_position || initialUser.use_arm_position,
    use_leg_position: rack?.use_leg_position || initialUser.use_leg_position,


    use_arm_angle: rack?.use_arm_angle || initialUser.use_arm_angle,
    use_top_feet_spoiler_location_id: rack?.use_top_feet_spoiler_location_id || initialUser.use_top_feet_spoiler_location_id,
    use_rack_location_id: rack?.use_rack_location_id || initialUser.use_rack_location_id,
    use_top_strap_location_id: rack?.use_top_strap_location_id || initialUser.use_top_strap_location_id,



    use_bottom_strap_location_id: rack?.use_bottom_strap_location_id || initialUser.use_bottom_strap_location_id,
    use_bottom_feet_surface_id: rack?.use_bottom_feet_surface_id || initialUser.use_bottom_feet_surface_id,
    use_position_with_spoiler: rack?.use_position_with_spoiler || initialUser.use_position_with_spoiler,
    use_position_without_spoiler: rack?.use_position_without_spoiler || initialUser.use_position_without_spoiler,
    use_lower_feet_to_crossbar: rack?.use_lower_feet_to_crossbar || initialUser.use_lower_feet_to_crossbar,
    use_lower_feet_location_id: rack?.use_lower_feet_location_id || initialUser.use_lower_feet_location_id
  });


  const formik = useFormik({
    initialValues: modelForVehicle,
    validationSchema: AddModel,
    onSubmit: async (values, { setSubmitting }) => {
      console.log("__________________________________________________rackType?.value", revieverClass?.value == "Receiver Classe", revieverClass);

      var errorStatus = false;
      if (rackType?.value == "Rack Type") {
        error11("Please selec the rack type");
        errorStatus = false;
      } 
      // else if (rackSupport?.value == "Rack Support Style") {
      //   console.log("____________________________________________________________________ASfsafs")
      //   error22("Please select the Rack Support Type");
      //   errorStatus = false;
      // }
      //  else if (revieverClass?.value == "Receiver Classe") {
      //   error33("Please select the Receiver Class");
      //   errorStatus = false;
      // } 
      else {
        error11("");
        error22("");
        error33("");

        errorStatus = true;
        setSubmitting(true)
        try {

          let payload = {
            rack_name: values?.name,
            obsolete_ind: inputField.obsolete ? inputField.obsolete : false,
            rack_number: values?.rack_number,
            rack_type_id: rackType?.value,
            rack_support_style_id: rackSupport?.value,
            receiver_class_id: revieverClass?.value,
            max_bikes: values?.max_bikes,
            tilt_ind: inputField?.tiltsRacks,
            heavy_bike_ind: inputField?.heavy_bikes_Racks,
            fit_guide_column: values?.fit_guide_column,
            fit_guide_group: values?.fit_guide_group ? values.fit_guide_group : 'test fit guide',
            use_rack_saddle_to_ground: inputField.use_rack_saddle_to_ground,
            use_trunk_opens_with_clips_ind: inputField.use_trunk_opens_with_clips_ind,
            use_rack_saddle_to_license: inputField.use_rack_saddle_to_license,
            use_arm_position: inputField.use_arm_position,
            use_leg_position: inputField.use_leg_position,
            use_arm_angle: inputField.use_arm_angle,
            use_top_feet_spoiler_location_id: inputField.use_top_feet_spoiler_location_id,
            use_rack_location_id: inputField.use_rack_location_id,
            use_top_strap_location_id: inputField.use_top_strap_location_id,
            use_bottom_strap_location_id: inputField.use_bottom_strap_location_id,
            use_bottom_feet_surface_id: inputField.use_bottom_feet_surface_id,
            use_position_with_spoiler: inputField.use_position_with_spoiler,
            use_position_without_spoiler: inputField.use_position_without_spoiler,
            use_lower_feet_to_crossbar: inputField.use_lower_feet_to_crossbar,
            use_lower_feet_location_id: inputField.use_lower_feet_location_id,
            vm_product_product_id: 0
          };

          let result = await createCustomRack(payload);

          if (result?.status === 200) {
            await SwalResponse('success', 'Rack Added', MESSAGES.RACK_ADDED);
            navigate("/admin/racks")

            //call the api for consume the rack apis


          } else {
            SwalResponse('error', 'warning', MESSAGES.SOMETHING_WENT_WRONG);
          }




        } catch (ex) {
          console.log("____________________________________ex is here", ex);

        } finally {
          setSubmitting(true);
          // cancel(true);
        }
      }
    },
  });


  return (
    <>
      <ToolbarWrapper />
      <Content>
        <form
          id="kt_modal_add_user_form"
          className="form"
          onSubmit={formik.handleSubmit}
          noValidate
        >
          <div className="card mb-5 mb-xl-10" id="kt_profile_details_view">
            <div className="card-header">
              <div className="card-title m-0">
                <h3 className="fw-bold m-0">Rack Details</h3>
              </div>
              {/* <a href="/" className="btn btn-sm btn-warning align-self-center">
              Edit Rack
            </a> */}
            </div>
            <div className="card-body">
              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Name
                </label>
                <div className="col-lg-8 fv-row fv-plugins-icon-container">
                  <input type="text"
                    {...formik.getFieldProps('name')}
                    name="name"
                    placeholder="Name"
                    // className="form-control mb-3 mb-lg-0"
                    className={clsx(
                      'form-control mb-3 mb-lg-0',
                      { 'is-invalid': formik.touched.name && formik.errors.name },
                      {
                        'is-valid': formik.touched.name && !formik.errors.name,
                      }
                    )}
                    disabled={formik.isSubmitting || isUserLoading}
                  />

                  {formik.touched.name && formik.errors.name && (
                    <div className="fv-plugins-message-container">
                      <div className="fv-help-block">
                        <span role="alert">{formik.errors.name}</span>
                      </div>
                    </div>
                  )}
                </div>

              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6"></label>
                <div className="col-lg-8 fv-row fv-plugins-icon-container">
                  <div className="d-flex align-items-center mt-3">
                    <label className="form-check form-check-custom form-check-inline me-5">
                      <input
                        className="form-check-input"
                        name="communication[]"
                        type="checkbox"
                        value={inputField.obsolete}
                        checked={inputField.obsolete}
                        onChange={(e) => setInputFields({ ...inputField, obsolete: e.target.checked })}
                      />
                      <span className="fw-semibold ps-2 fs-6">Obsolete</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Rack Number
                </label>
                <div className="col-lg-8 fv-row fv-plugins-icon-container">
                  <input type="text" minLength={10}
                    {...formik.getFieldProps('rack_number')}
                    name="rack_number"
                    placeholder="Rack Number"
                    // className="form-control mb-3 mb-lg-0"
                    className={clsx(
                      'form-control mb-3 mb-lg-0',
                      { 'is-invalid': formik.touched.rack_number && formik.errors.rack_number },
                      {
                        'is-valid': formik.touched.rack_number && !formik.errors.rack_number,
                      }
                    )}
                    disabled={formik.isSubmitting || isUserLoading}
                  />

                  {formik.touched.rack_number && formik.errors.rack_number && (
                    <div className="fv-plugins-message-container">
                      <div className="fv-help-block">
                        <span role="alert">{formik.errors.rack_number}</span>
                      </div>
                    </div>
                  )}

                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Type
                </label>

                <div
                  className="col-lg-8 fv-row fv-plugins-icon-container"
                  data-select2-id="select2-data-281-edpc"
                >
                  {/* <select
                  name="language"
                  aria-label="Select a Language"
                  data-control="select2"
                  data-placeholder="Trunk"
                  className="form-select form-select-solid form-select-lg select2-hidden-accessible"
                  data-select2-id="select2-data-12-lswl"
                  aria-hidden="true"
                  data-kt-initialized="1"
                >
                  <option value="" data-select2-id="select2-data-14-chmy">
                    Trunk
                  </option>
                  <option
                    data-kt-flag="flags/indonesia.svg"
                    value="id"
                    data-select2-id="select2-data-282-ssyf"
                  >
                    Bahasa Indonesia - Indonesian
                  </option>
                </select> */}

                  <Select
                    {...formik.getFieldProps('rack_type_id')}
                    className="select2-hidden-accessible sel-box"
                    placeholder="Type"
                    options={types}
                    value={rackType}
                    onChange={(e) => handleChangeRack(e, "racktype")}
                  />
                  <span className="danger text-danger">{error1}</span>


                  {/* {formik.touched.rack_type_id && formik.errors.rack_type_id && (
                    <div className="fv-plugins-message-container">
                      <div className="fv-help-block">
                        <span role="alert">{formik.errors.rack_type_id}</span>
                      </div>
                    </div>
                  )} */}



                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Rack Support Style
                </label>

                <div
                  className="col-lg-8 fv-row fv-plugins-icon-container"
                  data-select2-id="select2-data-281-edpc"
                >
                  {/* <select
                  name="language"
                  aria-label="Rack Support Style"
                  data-control="select2"
                  data-placeholder="Trunk"
                  className="form-select form-select-solid form-select-lg select2-hidden-accessible"
                  data-select2-id="select2-data-12-lswl"
                  aria-hidden="true"
                  data-kt-initialized="1"
                >
                  <option value="" data-select2-id="select2-data-14-chmy">
                    Rack Support Style
                  </option>
                  <option
                    data-kt-flag="flags/indonesia.svg"
                    value="id"
                    data-select2-id="select2-data-282-ssyf"
                  >
                    Bahasa Indonesia - Indonesian
                  </option>
                </select> */}

                  <Select
                    className="select2-hidden-accessible sel-box"
                    placeholder="Rack Support Style"

                    options={support}
                    value={rackSupport}
                    onChange={(e) => handleChangeRack(e, "racksupport")}


                  />
                  {/* <span className="danger text-danger">{error2}</span> */}
                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Receiver Class
                </label>

                <div
                  className="col-lg-8 fv-row fv-plugins-icon-container"
                  data-select2-id="select2-data-281-edpc"
                >
                  {/* <select
                  name="language"
                  aria-label="Select"
                  data-control="select2"
                  data-placeholder="Trunk"
                  className="form-select form-select-solid form-select-lg select2-hidden-accessible"
                  data-select2-id="select2-data-12-lswl"
                  aria-hidden="true"
                  data-kt-initialized="1"
                >
                  <option value="" data-select2-id="select2-data-14-chmy">
                    Select
                  </option>
                  <option
                    data-kt-flag="flags/indonesia.svg"
                    value="id"
                    data-select2-id="select2-data-282-ssyf"
                  >
                    Bahasa Indonesia - Indonesian
                  </option>
                </select> */}

                  <Select
                    className="select2-hidden-accessible sel-box"
                    placeholder="Rack Support Style"
                    value={revieverClass}
                    onChange={(e) => handleChangeRack(e, "recieverclass")}
                    options={reciever}

                  />
                  {/* <span className="danger text-danger">{error3}</span> */}
                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Maximum Bikes
                </label>
                <div className="col-lg-8 fv-row fv-plugins-icon-container">
                  <input type="number" min={0}
                    {...formik.getFieldProps('max_bikes')}
                    name="max_bikes"
                    placeholder="rack max_bikes"
                    // className="form-control mb-3 mb-lg-0"
                    className={clsx(
                      'form-control mb-3 mb-lg-0',
                      { 'is-invalid': formik.touched.max_bikes && formik.errors.max_bikes },
                      {
                        'is-valid': formik.touched.max_bikes && !formik.errors.max_bikes,
                      }
                    )}
                    disabled={formik.isSubmitting || isUserLoading}
                  />

                  {formik.touched.max_bikes && formik.errors.max_bikes && (
                    <div className="fv-plugins-message-container">
                      <div className="fv-help-block">
                        <span role="alert">{formik.errors.max_bikes}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6"></label>
                <div className="col-lg-8 fv-row fv-plugins-icon-container">
                  <div className="d-flex align-items-center mt-3">
                    <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                      <input
                        className="form-check-input"
                        name="communication[]"
                        type="checkbox"
                        value={inputField.tiltsRacks}
                        onChange={(e) => setInputFields({ ...inputField, tiltsRacks: e.target.checked })}
                      />
                      <span className="fw-semibold ps-2 fs-6">Tilts</span>
                    </label>

                    <label className="form-check form-check-custom form-check-inline form-check-solid me-5">
                      <input
                        className="form-check-input"
                        name="communication[]"
                        type="checkbox"
                        value={inputField.heavy_bikes_Racks}
                        onChange={(e) => setInputFields({ ...inputField, heavy_bikes_Racks: e.target.checked })}
                      />
                      <span className="fw-semibold ps-2 fs-6">
                        Electric/Heavy Bikes
                      </span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Fit Guide
                </label>
                <div className="col-lg-8">
                  <div className="row">
                    <div className="col-lg-6 fv-row fv-plugins-icon-container">
                      <input type="number" min={0}
                        {...formik.getFieldProps('fit_guide_column')}
                        name="fit_guide_column"
                        placeholder="Fit Guide"
                        // className="form-control mb-3 mb-lg-0"
                        className={clsx(
                          'form-control mb-3 mb-lg-0',
                          { 'is-invalid': formik.touched.fit_guide_column && formik.errors.fit_guide_column },
                          {
                            'is-valid': formik.touched.fit_guide_column && !formik.errors.fit_guide_column,
                          }
                        )}
                        disabled={formik.isSubmitting || isUserLoading}
                      />

                      {formik.touched.fit_guide_column && formik.errors.fit_guide_column && (
                        <div className="fv-plugins-message-container">
                          <div className="fv-help-block">
                            <span role="alert">{formik.errors.fit_guide_column}</span>
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="col-lg-6 fv-row fv-plugins-icon-container">
                      <input
                        type="text"
                        {...formik.getFieldProps('fit_guide_group')}
                        name="fit_guide_group"
                        placeholder="Fit Guid Group"
                        // className="form-control mb-3 mb-lg-0"
                        className={clsx(
                          'form-control mb-3 mb-lg-0',
                          { 'is-invalid': formik.touched.fit_guide_group && formik.errors.fit_guide_group },
                          {
                            'is-valid': formik.touched.fit_guide_group && !formik.errors.fit_guide_group,
                          }
                        )}
                        disabled={formik.isSubmitting || isUserLoading}
                      />
                    </div>
                    <div className="form-text">
                      If Column is not empty, the rack will be shown on the fit
                      guide. Use Group to put the fit information for more than
                      one rack in the same column.
                    </div>
                  </div>
                </div>
              </div>

              <div className="row mb-6">
                <label className="col-lg-4 col-form-label fw-semibold fs-6">
                  Overview
                </label>
                <div className="col-lg-8 fv-row fv-plugins-icon-container">
                  <textarea
                    {...formik.getFieldProps("rack_overview")}
                    name="rack_overview"
                    placeholder="Overview"
                    className="form-control mb-3 mb-lg-0"
                  >    Rack Overview</textarea>

                </div>
              </div>
            </div>
          </div>

          <div className="card mb-5 mb-xl-10">
            <div className="card-header">
              <div className="card-title m-0">
                <h3 className="fw-bold m-0">Fit Input Fields</h3>
              </div>
            </div>
            <div className="card-body">
              <div className="row ">
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_position_with_spoiler[]"
                      type="checkbox"
                      value={inputField.feet_spoiler}
                      checked={inputField.feet_spoiler}
                      onChange={(e) => setInputFields({ ...inputField, feet_spoiler: e.target.checked })}
                    />

                    {/* {formik.touched.use_position_with_spoiler && formik.errors.use_position_with_spoiler && (
                      <div className="fv-plugins-message-container">
                        <div className="fv-help-block">
                          <span role="alert">{formik.errors.use_position_with_spoiler}</span>
                        </div>
                      </div>
                    )} */}


                    <span className="fw-bold ps-2 fs-6">
                      Position With Spoiler
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      name="use_top_feet_spoiler_location_id[]"
                      type="checkbox"
                      className="form-check-input"
                      value={inputField.use_top_feet_spoiler_location_id}
                      checked={inputField.use_top_feet_spoiler_location_id}
                      onChange={(e) => setInputFields({ ...inputField, use_top_feet_spoiler_location_id: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Top Feet Spoiler Location
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_position_without_spoiler[]"
                      type="checkbox"
                      value={inputField.use_position_without_spoiler}
                      checked={inputField.use_position_without_spoiler}
                      onChange={(e) => setInputFields({ ...inputField, use_position_without_spoiler: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Position Without Spoiler
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                      value={inputField.use_rack_location_id}
                      checked={inputField.use_rack_location_id}
                      onChange={(e) => setInputFields({ ...inputField, use_rack_location_id: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">Rack Location</span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_trunk_opens_with_clips_ind[]"
                      type="checkbox"
                      value={inputField.use_trunk_opens_with_clips_ind}
                      checked={inputField.use_trunk_opens_with_clips_ind}
                      onChange={(e) => setInputFields({ ...inputField, use_trunk_opens_with_clips_ind: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Trunk Opens With Clips
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="communication[]"
                      type="checkbox"
                    />
                    <span className="fw-bold ps-2 fs-6">Top Strap Location</span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_arm_position[]"
                      type="checkbox"
                      value={inputField.use_arm_position}
                      checked={inputField.use_arm_position}
                      onChange={(e) => setInputFields({ ...inputField, use_arm_position: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">Arm Position</span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_bottom_strap_location_id[]"
                      type="checkbox"
                      value={inputField.use_bottom_strap_location_id}
                      checked={inputField.use_bottom_strap_location_id}
                      onChange={(e) => setInputFields({ ...inputField, use_bottom_strap_location_id: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Bottom Strap Location
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_leg_position[]"
                      type="checkbox"
                      value={inputField.use_leg_position}
                      checked={inputField.use_leg_position}
                      onChange={(e) => setInputFields({ ...inputField, use_leg_position: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">Leg Position</span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_bottom_feet_surface_id[]"
                      type="checkbox"
                      value={inputField.use_bottom_feet_surface_id}
                      checked={inputField.use_bottom_feet_surface_id}
                      onChange={(e) => setInputFields({ ...inputField, use_bottom_feet_surface_id: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">Bottom Feet Surface</span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_rack_saddle_to_ground[]"
                      type="checkbox"
                      value={inputField.use_rack_saddle_to_ground}
                      checked={inputField.use_rack_saddle_to_ground}
                      onChange={(e) => setInputFields({ ...inputField, use_rack_saddle_to_ground: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Rack Saddle To Ground
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_lower_feet_to_crossbar[]"
                      type="checkbox"
                      value={inputField.use_lower_feet_to_crossbar}
                      checked={inputField.use_lower_feet_to_crossbar}
                      onChange={(e) => setInputFields({ ...inputField, use_lower_feet_to_crossbar: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Lower Feet To Crossbar
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_rack_saddle_to_licenseW[]"
                      type="checkbox"
                      value={inputField.use_rack_saddle_to_license}
                      checked={inputField.use_rack_saddle_to_license}
                      onChange={(e) => setInputFields({ ...inputField, use_rack_saddle_to_license: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">
                      Rack Saddle To License
                    </span>
                  </label>
                </div>
                <div className="col-lg-3 fv-row mb-6">
                  <label className="form-check form-check-inline form-check-solid me-5">
                    <input
                      className="form-check-input"
                      name="use_arm_angle[]"
                      type="checkbox"
                      value={inputField.use_arm_angle}
                      checked={inputField.use_arm_angle}
                      onChange={(e) => setInputFields({ ...inputField, use_arm_angle: e.target.checked })}
                    />
                    <span className="fw-bold ps-2 fs-6">Angle of Arms</span>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="mb-5 mb-xl-10">

            <div className="d-flex">
              <button type="submit" id="kt_ecommerce_add_product_submit" className="btn btn-warning">
                <span className="indicator-label">Submit</span></button>
            </div>

          </div>
        </form>
        {/* {(formik.isSubmitting || isUserLoading) && <RegionListing />} */}
      </Content>
    </>
  );
};

export { AddNewRacks };
