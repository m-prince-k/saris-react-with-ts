import { FC, useEffect, useState } from "react";
import { ToolbarWrapper } from "../../../../../_metronic/layout/components/toolbar";
import { Link } from "react-router-dom";

import {
  getRackListingByTypes,
  getRackSupport,
  getRackTypes,
} from "./core/_requests";
import { RackListLoading } from "./components/loading/RackListLoading";
import { KTCardBody } from "../../../../../_metronic/helpers";
import { RackTable } from "./components/table/RackTable";
import { PaginatedItems } from "./components/pagination/ReactPagination";

const Racks: FC = () => {
  const [customRackType, setCustomRackType] = useState<any>([]);

  const [customRackSupport, setCustomRackSupport] = useState<any>([]);

  const [maxBikes, setMaxBikes] = useState<any>([]);

  const [rackSupport, setRackSupport] = useState<[]>();

  const [rackObsolete, setObsolete] = useState<any | undefined>(false); //obsolte

  const [listing, listingRacks] = useState([]); //to get all listing

  const [loading, setLoading] = useState<boolean | false>(true);
  const [page, setPage] = useState(0);

  const checkedRackTypeIds = customRackType
    .filter((rt: any) => rt.isChecked) // Filter items where isChecked is true
    .map((rt: any) => rt.rack_type_id);


  //customRackSupport

  const checkedRackSupportIds = customRackSupport
    .filter((rt: any) => rt.isChecked) // Filter items where isChecked is true
    .map((rt: any) => rt.rack_support_style_id);

  useEffect(() => {
    consumeRackTypes();
    consumeBodyStyle();
  }, []);

  const n = 3;

  useEffect(() => {
    fetchConfigApi(
      maxBikes,
      checkedRackSupportIds,
      rackObsolete,
      checkedRackTypeIds
    );
  }, [maxBikes, customRackSupport, rackObsolete, customRackType, page]);

  async function fetchConfigApi(
    maxBikes: any,
    checkedRackSupportIds: any,
    racksObsolete: any,
    checkedRackTypeIds: any
  ) {
    try {
      let data = {
        max_bikes: maxBikes,
        rack_support_style_id: checkedRackSupportIds,
        rack_type_id: checkedRackTypeIds,
        obsolete_ind: racksObsolete,
      };

      let { data: result, message, status } = await getRackListingByTypes(data);

      if (status === 200 && message == "Rack List") {

        listingRacks(result);

        setLoading(false);
      } else {
        setLoading(false);
      }
    } catch (error) {
      throw error;
    }
  }

  async function consumeRackTypes() {
    try {
      setLoading(true);

      const { data } = await getRackTypes();
      if (data?.length > 0) {
        const updatedData = data.map((obj: any) => ({
          ...obj,
          isChecked: true,
        }));
        setCustomRackType(updatedData);

        setLoading(false);
      }
    } catch (error) {
      throw error;
    }
  }

  async function consumeBodyStyle() {
    try {

      setLoading(true);

      const { data } = await getRackSupport();
      if (data?.length > 0) {
        const updatedData = data.map((obj: any) => ({
          ...obj,
          isChecked: true,
        }));
        setCustomRackSupport(updatedData);

        setLoading(false);
      }
    }
    catch (error) {
      throw error;
    }
  }

  const handleRackTypes = (e: any, rackTypeId: number) => {
    const updatedRackTypes = customRackType?.map((val: any) =>
      val.rack_type_id === rackTypeId
        ? { ...val, isChecked: e.target.checked }
        : val
    );
    setCustomRackType(updatedRackTypes);
  };

  const handleRackSupport = (e: any, rackSupportId: number) => {
    const updatedRackSupport = customRackSupport?.map((val: any) =>
      val.rack_support_style_id === rackSupportId ? { ...val, isChecked: e.target.checked } : val
    );
    setCustomRackSupport(updatedRackSupport);
  };

  const maxBikesHandleChange = (e: any) => {
    let newArray = [...maxBikes, parseInt(e.target.value)];
    if (maxBikes.includes(parseInt(e.target.value))) {
      newArray = newArray.filter((day) => day !== parseInt(e.target.value));
    }
    setMaxBikes(newArray);
  };

  const obj = {
    items: listing,
    itemsPerPage: 10,
    loading:loading
  }

  return (
    <>
      <ToolbarWrapper />
      <KTCardBody className="py-4">
        <div className="app-container container-fluid">
          <div className="card mb-5 mb-xl-10">
            <div id="kt_account_settings_notifications" className="">
              <div className="card card-custom">
                <div className="card-body">
                  <div className="row ">
                    <div className="col-lg-12 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={rackObsolete}
                          checked={rackObsolete}
                          onChange={(e) => setObsolete(e.target.checked)}
                        />
                        <span className="fw-bold ps-2 fs-6">
                          Show Obsolete Racks
                        </span>
                      </label>
                    </div>
                    <br />
                    <h6 className="mb-5">Rack Types:</h6>
                    {/* loop will be iterated start here */}

                    {loading ? (
                      <RackListLoading />
                    ) : (
                      customRackType?.map(
                        (val: {
                          rack_type_id: number;
                          rack_type_name: string;
                          isChecked: boolean;
                        }) => (
                          <>
                            <div className="col-lg-3 fv-row mb-6">
                              <label className="form-check form-check-inline form-check-solid me-5">
                                <input
                                  className="form-check-input"
                                  name="rackType[]"
                                  type="checkbox"
                                  onChange={(e) =>
                                    handleRackTypes(e, val.rack_type_id)
                                  }
                                  checked={val.isChecked}
                                // value = {setShowRacks(val.rack_type_id)}
                                // value={+val.rack_type_id || ""}
                                />
                                <span className="fw-bold ps-2 fs-6">
                                  {val.rack_type_name}
                                </span>
                              </label>
                            </div>
                          </>
                        )
                      )
                    )}
                  </div>
                  <div className="row">
                    <h6 className="mb-5">Rack Supports:</h6>
                    {loading ? (
                      <RackListLoading />
                    ) : (
                      customRackSupport &&
                      customRackSupport.map(
                        (val: {
                          rack_support_style_name: string;
                          rack_support_style_id: number;
                          isChecked: boolean;
                        }) => (
                          <>
                            <div className="col-lg-3 fv-row mb-6">
                              <label className="form-check form-check-inline form-check-solid me-5">
                                <input
                                  className="form-check-input"
                                  name="communication[]"
                                  type="checkbox"
                                  value={+val.rack_support_style_id || ""}
                                  onChange={(e) => handleRackSupport(e, val.rack_support_style_id)}
                                  checked={val.isChecked}
                                />
                                <span className="fw-bold ps-2 fs-6">
                                  {val.rack_support_style_name || ""}
                                </span>
                              </label>
                            </div>
                          </>
                        )
                      )
                    )}
                  </div>

                  <div className="row">
                    <h6 className="mb-5">Max Bikes:</h6>
                    <div className="col-lg-3 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={0}
                          onChange={maxBikesHandleChange}
                        //checked={maxBikes}
                        />
                        <span className="fw-bold ps-2 fs-6">0</span>
                      </label>
                    </div>

                    <div className="col-lg-3 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={1}
                          onChange={maxBikesHandleChange}
                        />
                        <span className="fw-bold ps-2 fs-6">1</span>
                      </label>
                    </div>

                    <div className="col-lg-3 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={2}
                          onChange={maxBikesHandleChange}
                        />
                        <span className="fw-bold ps-2 fs-6">2</span>
                      </label>
                    </div>

                    <div className="col-lg-3 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={3}
                          onChange={maxBikesHandleChange}
                        />
                        <span className="fw-bold ps-2 fs-6">3</span>
                      </label>
                    </div>

                    <div className="col-lg-3 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={4}
                          onChange={maxBikesHandleChange}
                        />
                        <span className="fw-bold ps-2 fs-6">4</span>
                      </label>
                    </div>

                    <div className="col-lg-3 fv-row mb-6">
                      <label className="form-check form-check-inline form-check-solid me-5">
                        <input
                          className="form-check-input"
                          name="communication[]"
                          type="checkbox"
                          value={5}
                          onChange={maxBikesHandleChange}
                        />
                        <span className="fw-bold ps-2 fs-6">5</span>
                      </label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="card mb-5 mb-xl-10">
            <div className="card-header border-0 pt-6">
              <div className="card-title">
                <div className="d-flex align-items-center position-relative my-1">
                  <i className="ki-duotone ki-magnifier fs-1 position-absolute ms-6">
                    <span className="path1"></span>
                    <span className="path2"></span>
                  </i>
                  <input
                    type="text"
                    data-kt-user-table-filter="search"
                    className="form-control form-control-solid w-250px ps-14"
                    placeholder="Search Vehicles"
                    value=""
                  />
                </div>
              </div>
              <div className="card-toolbar">
                <div
                  className="d-flex justify-content-end"
                  data-kt-user-table-toolbar="base"
                >
                  <Link
                    to={"/admin/racks/add-racks"}
                    className="btn btn-warning"
                  >
                    <i className="ki-duotone ki-plus fs-2"></i> Add Racks
                  </Link>
                  {/* <button type="button" className="btn btn-warning">
                  <i className="ki-duotone ki-plus fs-2"></i>Add Rack
                </button> */}
                </div>
              </div>
            </div>

                    
            {listing && (<PaginatedItems {...obj} />)}
          </div>
        </div>
      </KTCardBody>
    </>
  );
};

export { Racks };
