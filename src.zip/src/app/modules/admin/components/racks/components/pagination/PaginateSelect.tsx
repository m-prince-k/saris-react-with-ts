const PaginateSelect  = () => {
    return (
        <>
           
        </>
    )
}

export {PaginateSelect};