import { useEffect, useState } from "react";
import ReactPaginate from "react-paginate";
import { RackTable } from "../table/RackTable";
import { RackListLoading } from "../loading/RackListLoading";
import Select from "react-select";
import { PaginateSelect } from "./PaginateSelect";


export const PaginatedItems = (obj: any) => {
  // We start with an empty list of items.
  const array=[15,30,75,100];

  const items=obj?.items;
  const itemsPerPage = obj?.itemsPerPage;
  const loading = obj?.loading;


  console.log("_________________loading is here",loading)


  const [currentItems, setCurrentItems] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [pageNumber, setPageNumber] = useState(0);
  // Here we use item offsets; we could also use page offsets
  // following the API or data you're working with.
  const [itemOffset, setItemOffset] = useState(0);


  

  useEffect(() => {
    // Fetch items from another resources.
    const endOffset = itemOffset + itemsPerPage;
    console.log(`Loading items from ${itemOffset} to ${endOffset}`);

    setCurrentItems(items.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(items.length / itemsPerPage));
  }, [itemOffset, itemsPerPage,items]);

  // Invoke when user click to request another page.
  const handlePageClick = (event: any) => {
    const newOffset = event.selected * itemsPerPage % items.length;
    console.log(`User requested page number ${event.selected}, which is offset ${newOffset}`);
    setItemOffset(newOffset);
  };
 

  return (
    <>
   {
    loading ? <RackListLoading/> : 
    <>
    <RackTable data={currentItems} loading={loading} />
    <PaginateSelect />
    </>
   }
   
    <ReactPaginate
      nextLabel="NEXT >"
      onPageChange={(event) => handlePageClick(event)}
      pageRangeDisplayed={3}
      marginPagesDisplayed={2}
      pageCount={pageCount}
      previousLabel="< PREVIOUS"
      pageClassName="page-item"
      pageLinkClassName="page-link"
      previousClassName="page-item"
      previousLinkClassName="page-link"
      nextClassName="page-item"
      nextLinkClassName="page-link"
      breakLabel="..."
      breakClassName="page-item"
      breakLinkClassName="page-link"
      containerClassName="pagination"
      activeClassName="active"
      renderOnZeroPageCount={null}
    /> 
    Total Record: {items?.length || 0}
   
    </>
  );
}