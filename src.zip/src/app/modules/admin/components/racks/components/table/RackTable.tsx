import { OverlayTrigger, Tooltip } from "react-bootstrap";
import { RackListPagination } from "../pagination/RackListPagination";
import { Link } from "react-router-dom";
import { FC, useState } from "react";
import { initialUser, Rack } from "../../../racks/core/_models";
import { RackListLoading } from "../loading/RackListLoading";

type Props = [];

const RackTable = ({ data }: any, { loading }: any) => {


  // console.log("select value is here000000000000000000000000000000000020020202020",rackData)



  const onTooltipChange = (message: string) => {
    const tooltip = (
      <Tooltip id="tooltip">
        <strong>{message}</strong>
      </Tooltip>
    );
    return tooltip;
  };


  const sortTypes = {
    up: {
      class: 'sort-up',
      fn: (a:any, b:any) => a.net_worth - b.net_worth
    },
    down: {
      class: 'sort-down',
      fn: (a:any, b:any) => b.net_worth - a.net_worth
    },
    default: {
      class: 'sort',
      fn: (a:any, b:any) => a
    }
  }



  const onSortChange = () => {
    const [currentSort,setCurrentSort]=useState("");

		// const { currentSort } = this.state;
		let nextSort:string="";
		
		if(currentSort === 'down') nextSort = 'up';
		else if(currentSort === 'up') nextSort = 'default';
		else if(currentSort === 'default') nextSort = 'down';
		
		setCurrentSort(nextSort);
	}


  
  return (
    <>
      <div className="card-body pt-0 ">
        <div
          id="kt_customers_table_wrapper"
          className="dt-container dt-bootstrap5 dt-empty-footer"
        >
          <div id="" className="table-responsive">
            <table
              className="table align-middle table-row-dashed fs-6 gy-5 dataTable"
              id="kt_customers_table"
            >
              <colgroup>
                <col data-dt-column="0" />
                <col data-dt-column="1" />
                <col data-dt-column="2" />
                <col data-dt-column="3" />
                <col data-dt-column="4" />
                <col data-dt-column="5" />
                <col data-dt-column="6" />
              </colgroup>
              <thead>
                <tr
                  className="text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0"
                  role="row"
                >
                  <th className="w-10px pe-2 dt-orderable-none">
                    <div className="d-flex align-items-center">
                      Obs
                      <OverlayTrigger
                        placement="top"
                        overlay={onTooltipChange("Rack is obsolete.")}
                      >
                        <i className="ki-duotone ki-question-2 fs-4 ms-2 cursor-pointer">
                          <span className="path1"></span>
                          <span className="path2"></span>
                        </i>
                      </OverlayTrigger>
                    </div>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="1"
                    aria-label="Customer Name: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Rack
                      <button onClick={onSortChange}>
								<i className={`fas fa-plus`}></i>
							</button>
                    </span>
                    <span className="dt-column-order"></span>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="2"
                    aria-label="Email: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Number
                    </span>
                    <span className="dt-column-order"></span>
                  </th>
                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="3"
                    aria-label="Company: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Type
                    </span>
                    <span className="dt-column-order"></span>
                  </th>
                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="4"
                    aria-label="Payment Method: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Style
                    </span>
                    <span className="dt-column-order"></span>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <div className="d-flex align-items-center">
                      Class
                      <OverlayTrigger
                        placement="top"
                        overlay={onTooltipChange(
                          "The hitch receiver class required for the rack."
                        )}
                      >
                        <i className="ki-duotone ki-question-2 fs-4 ms-2 cursor-pointer">
                          <span className="path1"></span>
                          <span className="path2"></span>
                        </i>
                      </OverlayTrigger>
                    </div>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Bikes
                    </span>
                    <span className="dt-column-order"></span>
                  </th>
                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Tilting
                    </span>
                    <span className="dt-column-order"></span>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <div className="d-flex align-items-center">
                      <span className="dt-column-title" role="button">
                        Heavy
                      </span>
                      <span className="dt-column-order"></span>
                      <OverlayTrigger
                        placement="top"
                        overlay={onTooltipChange(
                          "The rack supports electric/heavy bikes."
                        )}
                      >
                        <i className="ki-duotone ki-question-2 fs-4 ms-2 cursor-pointer">
                          <span className="path1"></span>
                          <span className="path2"></span>
                        </i>
                      </OverlayTrigger>
                    </div>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <div className="d-flex align-items-center">
                      <span className="dt-column-title" role="button">
                        Column
                      </span>
                      <span className="dt-column-order"></span>
                      <OverlayTrigger
                        placement="top"
                        overlay={onTooltipChange(
                          "The column number in the printed fit guide. Empty if the rack is not included in the fit guide."
                        )}
                      >
                        <i className="ki-duotone ki-question-2 fs-4 ms-2 cursor-pointer">
                          <span className="path1"></span>
                          <span className="path2"></span>
                        </i>
                      </OverlayTrigger>
                    </div>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <div className="d-flex align-items-center">
                      <span className="dt-column-title" role="button">
                        Group
                      </span>
                      <span className="dt-column-order"></span>
                      <OverlayTrigger
                        placement="top"
                        overlay={onTooltipChange(
                          "The group in the fit guide. If empty, the rack is in its own group."
                        )}
                      >
                        <i className="ki-duotone ki-question-2 fs-4 ms-2 cursor-pointer">
                          <span className="path1"></span>
                          <span className="path2"></span>
                        </i>
                      </OverlayTrigger>
                    </div>
                  </th>

                  <th
                    className="min-w-125px dt-orderable-asc dt-orderable-desc"
                    data-dt-column="5"
                    aria-label="Created Date: Activate to sort"
                  >
                    <span className="dt-column-title" role="button">
                      Overview
                    </span>
                    <span className="dt-column-order"></span>
                  </th>
                </tr>
              </thead>

              {/* data consume is start here */}
              <tbody className="fw-semibold text-gray-600">
                {loading ? (
                  <RackListLoading />
                ) : data?.length > 0 ? (data.map((elem: {obsolete_ind: boolean;
                      rack_name: string;
                      rack_number: string;
                      rack_type: any;
                      rack_support_style: any;
                      receiver_class: any;
                      max_bikes: number;
                      tilt_ind: boolean;
                      heavy_bike_ind: boolean;
                      fit_guide_column: number;
                      fit_guide_group: string;
                      rack_overview: string;
                    }) => (
                      <>
                        <tr>
                          <td>
                            <div className="form-check form-check-sm form-check-custom form-check-solid">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                value={+elem.obsolete_ind}
                                checked={elem.obsolete_ind || false}
                              />
                            </div>
                          </td>
                          <td>
                            <Link
                              to={"/admin/racks/add-racks"}
                              className="text-gray-800 text-hover-primary mb-1"
                            >
                              {elem.rack_name || "N/A"}
                            </Link>

                            {/* <p className="text-gray-800 text-hover-primary mb-1">
                          Bones (2 Bike)
                        </p> */}
                          </td>
                          <td> {elem.rack_number || "N/A"}</td>
                          <td>{elem?.rack_type?.rack_type_name || "N/A"}</td>
                          <td>
                            {elem?.rack_support_style
                              ?.rack_support_style_name || "N/A"}
                          </td>
                          <td>
                            {elem?.receiver_class?.receiver_class_name || "N/A"}
                          </td>
                          <td>{elem?.max_bikes || "N/A"}</td>
                          <td>
                            <div className="form-check form-check-sm form-check-custom form-check-solid">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                value={+elem?.tilt_ind || "N/A"}
                                checked={elem?.tilt_ind || false}
                              />
                            </div>
                          </td>
                          <td>
                            <div className="form-check form-check-sm form-check-custom form-check-solid">
                              <input
                                className="form-check-input"
                                type="checkbox"
                                value={+elem?.heavy_bike_ind || "N/A"}
                                checked={elem?.heavy_bike_ind || false}
                              />
                            </div>
                          </td>
                          <td>{elem?.fit_guide_column || "N/A"}</td>
                          <td>{elem?.fit_guide_group || "N/A"}</td>
                          <td>
                            {elem &&
                              elem.rack_overview &&
                              (elem.rack_overview.length < 15 ? (
                                elem.rack_overview
                              ) : (
                                <span title={elem.rack_overview}>
                                  {elem.rack_overview.slice(0, 15)}
                                  <OverlayTrigger
                                    placement="top"
                                    overlay={onTooltipChange(
                                      elem.rack_overview
                                    )}
                                  >
                                    <i className="ki-duotone ki-information-2 text-gray-900 fs-4">
                                      <span className="path1"></span>
                                      <span className="path2"></span>
                                      <span className="path3"></span>
                                    </i>
                                  </OverlayTrigger>
                                </span>
                              ))}
                          </td>
                        </tr>
                      </>
                    )
                  )
                ) : (
                  <tr>
                    <td colSpan={7}>
                      <div className="d-flex text-center w-100 align-content-center justify-content-center">
                        No matching records found
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
              {/* end of data consume is here     */}
              <tfoot></tfoot>
            </table>
          </div>

                

          {/* pagination part start here */}
          {/* <RackListPagination /> */}
          {/* end of pagination part */}
        </div>
      </div>
    </>
  );
};

export { RackTable };
