import { ID, Response } from "../../../../../../_metronic/helpers"
export type Rack = {
  id?:ID
  name?:string;
  obsolete_ind?:boolean;
  rack_number?:string,
  rack_type_id?:number,
  rack_support_style_id?:number,
  receiver_class_id?:number,
  max_bikes?:number
  tilts?:boolean,
  heavy_bike_ind?:boolean,
  fit_guide_column?:number,
  fit_guide_group?:string,
  rack_overview?:string,
  listing?:[]
  avatar?:string,

  

  //fit input field type define here

    use_rack_saddle_to_ground?:boolean,
      use_trunk_opens_with_clips_ind?:boolean,
      use_rack_saddle_to_license?:boolean,
      use_arm_position?:boolean,
      use_leg_position?:boolean,
      use_arm_angle?:boolean,
      use_top_feet_spoiler_location_id?:boolean,
      use_rack_location_id?:boolean,
      use_top_strap_location_id?:boolean,
      use_bottom_strap_location_id?:boolean,
      use_bottom_feet_surface_id?:boolean,
      use_position_with_spoiler?:boolean,
      use_position_without_spoiler?:boolean,
      use_lower_feet_to_crossbar?:boolean,
      use_lower_feet_location_id?:boolean,
  initials?: {
    label: string;
    state: string;
  };
  reference?:number,
  note?:string,
  language?:string,
  no_fit_ind?:boolean
};

export type UsersQueryResponse = Response<Array<Rack>>;

export const initialUser: Rack = {
  listing:[],
  id:0,
  name:'',
  obsolete_ind:false,
  rack_number:'',
  rack_type_id:0,
  rack_support_style_id:0,
  receiver_class_id:0,
  max_bikes:0,
  tilts:false,
  heavy_bike_ind:false,
  fit_guide_column:0,
  fit_guide_group:'',
  rack_overview:'',
  
  use_rack_saddle_to_ground:false,
    use_trunk_opens_with_clips_ind:false,
      use_rack_saddle_to_license:false,
      use_arm_position:false,
      use_leg_position:false,
      use_arm_angle:false,
      use_top_feet_spoiler_location_id:false,
      use_rack_location_id:false,
      use_top_strap_location_id:false,
      use_bottom_strap_location_id:false,
      use_bottom_feet_surface_id:false,
      use_position_with_spoiler:false,
      use_position_without_spoiler:false,
      use_lower_feet_to_crossbar:false,
      use_lower_feet_location_id:false,
      avatar:''
};
