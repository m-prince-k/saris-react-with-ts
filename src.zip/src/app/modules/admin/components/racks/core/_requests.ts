import axios, { AxiosResponse } from "axios";
import { ID, Response } from "../../../../../../_metronic/helpers";
import { Rack, UsersQueryResponse } from "./_models";
import { RACK_ADMIN } from "../../../../../../util/constant";



const API_URL = import.meta.env.VITE_APP_THEME_API_URL;

const LOCAL_API_URL = import.meta.env.VITE_APP_THEME_LOCAL_API_URL;
const PREFIX = `admin/racks/`;
const RACK_URL = `${LOCAL_API_URL}/${PREFIX}`;

const GET_USERS_URL = `${API_URL}/users/query`;

const getUsers = (query: string): Promise<UsersQueryResponse> => {
  return axios
    .get(`${GET_USERS_URL}?${query}`)
    .then((d: AxiosResponse<UsersQueryResponse>) => d.data);
};

const getUserById = (id: ID): Promise<Rack | undefined> => {
  return axios
    .get(`${RACK_URL}/${id}`)
    .then((response: AxiosResponse<Response<Rack>>) => response.data)
    .then((response: Response<Rack>) => response.data);
};

const createUser = (notes: Rack): Promise<Rack | undefined> => {
  return axios
    .put(RACK_URL, notes)
    .then((response: AxiosResponse<Response<Rack>>) => response.data)
    .then((response: Response<Rack>) => response.data);
};

const updateUser = (user: Rack): Promise<Rack | undefined> => {
  return axios
    .post(`${RACK_URL}/${user.id}`, user)
    .then((response: AxiosResponse<Response<Rack>>) => response.data)
    .then((response: Response<Rack>) => response.data);
};

const deleteUser = (userId: ID): Promise<void> => {
  return axios.delete(`${RACK_URL}/${userId}`).then(() => { });
};

const deleteSelectedUsers = (userIds: Array<ID>): Promise<void> => {
  const requests = userIds.map((id) => axios.delete(`${RACK_URL}/${id}`));
  return axios.all(requests).then(() => { });
};

const createCustomRack = async (racks: Rack) => {
  try {

    let response = await axios.post(RACK_URL + RACK_ADMIN.ADD_NEW_RACK, racks);
    console.log("____________________________________vehicle is here", response.data)
    return await response.data;
  } catch (error) {
    console.log("_______________________________________", error);
    throw error;
  }
};

const getRackTypes = async () => {
  try {
    let response = await axios.get(RACK_URL + RACK_ADMIN.GET_RACKS_TYPE);
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}
const getRackSupport = async () => {
  try {
    let response = await axios.get(RACK_URL + RACK_ADMIN.RACK_SUPPORT_STYLE);
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}

const getRackReceiver = async () => {
  try {
    let response = await axios.get(RACK_URL + RACK_ADMIN.RECEIVER_CLASS);
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}

//get rackListing consume is here
const getRackListingByTypes = async (data:Rack) => {
  try {
    let response = await axios.post(RACK_URL + RACK_ADMIN.GET_RACK_BY_TYPES,data);
    console.log("types is here", await response.data)
    return await response.data;
  } catch (error) {
    console.log("__________________________error is here", error);
    throw error;
  }
}

//node connect 

export {
  getRackListingByTypes,
  getRackReceiver,
  getRackTypes,
  getUsers,
  deleteUser,
  deleteSelectedUsers,
  getUserById,
  createCustomRack,
  updateUser,
  createUser,
  getRackSupport
};
